"""
brighten.py - makes GAC Office Hunt brighter.
Put this file in C:\games\office_hunt\ (same folder as main.py) and run:
    python brighten.py
A backup is saved as main_backup.py before any change.
"""
import shutil
from pathlib import Path

target = Path(__file__).with_name("main.py")
src = target.read_text(encoding="utf-8")

CHANGES = [
    # (old, new, description)
    ("lm.fill((84, 88, 108))", "lm.fill((168, 170, 182))",
     "Room base light: 33% -> 66%"),
    ("strip = radial(300, 190, (122, 118, 108), power=1.5)",
     "strip = radial(300, 190, (90, 88, 80), power=1.5)",
     "Ceiling light pools (softer, since base is brighter)"),
    ("core = radial(130, 40, (46, 46, 42), power=1.2)",
     "core = radial(130, 40, (30, 30, 28), power=1.2)",
     "Ceiling light core"),
    ("LIGHTS_OFF = [(700, 190, 912, 320), (33, 563, 135, 643), (33, 285, 160, 366)]",
     "LIGHTS_OFF = [(33, 563, 135, 643)]",
     "Meeting room + server room lights ON (vacant room stays dark)"),
    ("lv.fill((40, 42, 52))", "lv.fill((120, 122, 132))",
     "Area outside the office + title screen"),
]

if "lm.fill((168, 170, 182))" in src:
    print("Already brightened. Nothing to do.")
    raise SystemExit

missing = [d for old, new, d in CHANGES if old not in src]
if missing:
    print("STOPPED - main.py is not the expected version. Nothing changed.")
    for d in missing:
        print("  not found:", d)
    raise SystemExit(1)

shutil.copy(target, target.with_name("main_backup.py"))
for old, new, d in CHANGES:
    n = src.count(old)
    src = src.replace(old, new)
    print(f"OK  {d}  ({n} place{'s' if n > 1 else ''})")
target.write_text(src, encoding="utf-8")
print("\nDone. Backup saved as main_backup.py")
