"""
GAC OFFICE HUNT  v2
Top-down 2D chase game based on the GAC Hong Kong seating plan (July 2026).

Run on PC:       pip install pygame-ce      ->  python main.py
Run in browser:  pip install pygbag         ->  python -m pygbag office_hunt

Controls:
    WASD / Arrow keys  Move
    Shift              Sprint (x1.5 for 1.5 s, 4 s cooldown)
    Tab                Show / hide name tags
    P                  Pause
    R                  Restart
    Esc                Quit

v2 changes: brighter lighting, performance caching (sprites, light, glows),
no slow-motion on catch, sprint, department rings, slower staff,
2.5 s card tap at the main door, clearer ISO punch, Ken goes for the weapon.
"""
import asyncio
import json
import math
import random
from collections import deque

import pygame

# =====================================================================
# CONFIG  (gameplay rules - edit here only)
# =====================================================================
SCREEN_W, SCREEN_H = 1280, 720
FPS = 60
GAME_TIME = 90.0          # seconds per round
HUNTER_SPEED = 240.0      # world px / s
SPRINT_MULT = 1.5
SPRINT_TIME = 1.5
SPRINT_COOLDOWN = 4.0
CATCH_DIST = 24
ISO_STUN = 2.0            # seconds hunter is stunned by Scott
POOP_BLIND = 3.0          # seconds the hunter's view is covered
COMBO_WINDOW = 4.0
ALARM_TIME = 30.0         # everyone starts running after this
ALERT_CELLS = 15          # path distance (cells) at which a seated person notices the hunter
PANIC_CELLS = 13
SWIPE_MAIN = 2.5          # seconds to tap access card at the main door (sofa)
SWIPE_SIDE = 1.3          # seconds to tap access card at the Printer 4525 door
KEN_TRIGGER = 14          # Ken runs for the weapon when the hunter is this close (cells)
KEN_BOOST = 1.22          # Ken's adrenaline speed while running for the weapon
HFIELD_DEPTH = 34         # how far (cells) staff "sense" the hunter - capped for speed
HIGHSCORE_FILE = "highscore.json"

LOVE_TARGET = "William Tse"
ISO_NAME = "Scott Cheong"
WEAPON_SEEKER = "Ken Tsui"

DEPTS = {
    #               colour             speed  noise react replan
    "Shipping":   dict(color=(222, 186, 60), speed=0.85, noise=0.35, react=0.5, replan=0.45),
    "Logistics":  dict(color=(104, 150, 214), speed=0.81, noise=0.08, react=0.4, replan=0.25),
    "Account":    dict(color=(132, 184, 120), speed=0.79, noise=0.00, react=1.3, replan=0.35),
    "IT":         dict(color=(232, 140, 80), speed=0.81, noise=0.20, react=0.6, replan=0.40),
    "HR":         dict(color=(226, 140, 160), speed=0.80, noise=0.20, react=0.6, replan=0.40),
    "Reception":  dict(color=(226, 140, 160), speed=0.80, noise=0.20, react=0.6, replan=0.40),
    "ISO":        dict(color=(160, 120, 214), speed=0.65, noise=0.00, react=0.8, replan=0.30),
    "Management": dict(color=(226, 226, 236), speed=0.76, noise=0.10, react=0.9, replan=0.35),
}

# name, department, chair x, chair y (seating-plan coordinates), facing (deg), points
STAFF = [
    ("Gavin Wong", "Account", 1018, 240, 180, 100),
    ("Havana Wong", "Account", 1018, 295, 180, 100),
    ("William Tse", "Account", 935, 295, 0, 100),
    ("Loretta Lo", "Account", 1018, 342, 180, 100),
    ("Scott Cheong", "ISO", 935, 342, 0, 500),
    ("Raymond Chan", "IT", 1098, 262, -90, 100),
    ("Grace Huang", "HR", 1140, 262, -90, 100),
    ("Venus Tong", "Account", 1134, 340, -90, 200),
    ("Shirley Fong", "Reception", 562, 333, -90, 100),
    ("Catherine Chan", "Logistics", 68, 437, -90, 100),
    ("Jason Chau", "Logistics", 334, 412, 180, 100),
    ("Peter Chan", "Logistics", 200, 458, 0, 100),
    ("Ken Tsui", "Logistics", 200, 506, 0, 100),
    ("Felix Yip", "Logistics", 334, 506, 180, 100),
    ("Ivan Yung", "Shipping", 369, 412, 0, 100),
    ("Jim Jim", "Shipping", 501, 412, 180, 100),
    ("Simon Nam", "Shipping", 501, 458, 180, 100),
    ("Bruce Leung", "Shipping", 369, 506, 0, 100),
    ("John Wong", "Shipping", 501, 506, 180, 100),
    ("Ryan Liu", "Shipping", 582, 412, 0, 100),
    ("Mike Cao", "Shipping", 682, 412, 180, 100),
    ("Wilson Yu", "Shipping", 582, 456, 0, 100),
    ("Kobi Tsui", "Shipping", 682, 456, 180, 100),
    ("Sammi Kwok", "Logistics", 230, 596, 90, 200),
    ("Dennis Lee", "Shipping", 402, 596, 90, 200),
    ("Maria Lam", "Management", 607, 588, 90, 300),
]
VACANT_SEATS = [(935, 240, 0), (200, 412, 0), (334, 458, 180), (369, 458, 0)]
LONG_HAIR = {"Grace Huang", "Shirley Fong", "Havana Wong", "Loretta Lo", "Venus Tong",
             "Catherine Chan", "Sammi Kwok", "Maria Lam"}
WEAPON_POS = (80, 606)

# =====================================================================
# MAP GEOMETRY (seating-plan coordinates, converted x2 to world pixels)
# =====================================================================
S = 2.0
CELL = 16
INFLATE = 9
LS = 2                    # lighting is rendered at 1/LS resolution (performance)
ANG_STEP = 10             # sprite rotation cache step (degrees)


def P(x, y):
    return ((x - 20) * S, (y - 160) * S)


def RP(x1, y1, x2, y2):
    ax, ay = P(x1, y1)
    bx, by = P(x2, y2)
    return pygame.Rect(round(ax), round(ay), round(bx - ax), round(by - ay))


WORLD_W, WORLD_H = int((1195 - 20) * S), int((670 - 160) * S)
GW, GH = WORLD_W // CELL + 1, WORLD_H // CELL + 1

FLOOR = [(33, 190, 690, 643), (690, 190, 1170, 388), (58, 170, 96, 192), (630, 170, 702, 192)]
EXIT_A = (58, 96)      # Printer 4525 door
EXIT_B = (630, 702)    # Main door (sofa) - hunter enters here
EXIT_Y = 44            # world y: crossing above this = escaped
MAIN_DOOR_X = (P(EXIT_B[0], 0)[0] - 20, P(EXIT_B[1], 0)[0] + 20)

WALLS_WINDOW = [(29, 186, 35, 647), (29, 641, 694, 647), (688, 386, 694, 647),
                (688, 386, 1174, 392), (1168, 186, 1174, 392)]
WALLS_SOLID = [(29, 184, 58, 192), (96, 184, 630, 192), (702, 184, 1174, 192),
               (54, 168, 58, 192), (96, 168, 100, 192), (626, 168, 630, 192), (702, 168, 706, 192)]
GLASS = [(698, 190, 702, 320), (698, 318, 780, 322), (830, 318, 914, 322), (910, 190, 914, 320),
         (1063, 283, 1170, 287), (1063, 283, 1067, 335), (1063, 372, 1067, 390),
         (33, 561, 100, 565), (128, 561, 150, 565), (188, 561, 430, 565), (470, 561, 630, 565),
         (672, 561, 690, 565), (133, 563, 137, 643), (313, 563, 317, 643), (493, 563, 497, 643)]
OBST = [
    ("pantry", 95, 192, 555, 226), ("sofa", 556, 204, 626, 226), ("printer", 58, 262, 118, 282),
    ("server", 33, 285, 160, 366), ("filing", 161, 285, 182, 306), ("table", 207, 285, 302, 366),
    ("reception", 520, 285, 605, 318),
    ("planter", 458, 285, 483, 306), ("planter", 484, 308, 509, 330),
    ("planter", 510, 331, 545, 354), ("planter", 546, 356, 581, 378),
    ("column", 292, 232, 306, 246), ("column", 640, 330, 654, 344),
    ("cluster", 950, 212, 1003, 362), ("desk", 1078, 228, 1158, 247), ("desk", 1108, 300, 1160, 322),
    ("desk", 38, 380, 142, 418), ("table", 57, 472, 145, 503),
    ("cluster", 215, 394, 319, 522), ("cluster", 383, 394, 487, 522), ("cluster", 596, 394, 668, 476),
    ("plantercab", 582, 494, 688, 516), ("bin", 606, 530, 628, 550), ("bin", 652, 530, 674, 550),
    ("printer", 56, 541, 106, 560),
    ("desk", 185, 610, 275, 630), ("cabinet", 285, 575, 310, 640),
    ("desk", 360, 610, 445, 630), ("cabinet", 465, 575, 490, 640),
    ("execdesk", 560, 600, 655, 628), ("cabinet", 500, 575, 520, 640),
    ("mtable", 740, 232, 870, 280), ("shelf", 38, 598, 54, 640),
]
LIGHTS_OFF = [(33, 563, 135, 643)]          # only the vacant (weapon) room stays dark


# =====================================================================
# SMALL HELPERS
# =====================================================================
def clamp(v, a, b):
    return a if v < a else b if v > b else v


def lerp(a, b, t):
    return a + (b - a) * t


def shade(c, k):
    return tuple(int(clamp(v * k, 0, 255)) for v in c)


def soften(surf, factor=4):
    w, h = surf.get_size()
    small = pygame.transform.smoothscale(surf, (max(1, w // factor), max(1, h // factor)))
    return pygame.transform.smoothscale(small, (w, h))


def radial(w, h, color, steps=28, power=1.8, alpha=False):
    flags = pygame.SRCALPHA if alpha else 0
    s = pygame.Surface((max(1, int(w)), max(1, int(h))), flags)
    s.fill((0, 0, 0, 0) if alpha else (0, 0, 0))
    for i in range(steps):
        f = 1 - i / steps
        k = ((i + 1) / steps) ** power
        rw, rh = w * f, h * f
        col = tuple(int(c * k) for c in color)
        if alpha:
            col = color[:3] + (int(color[3] * k),)
        pygame.draw.ellipse(s, col, ((w - rw) / 2, (h - rh) / 2, rw, rh))
    return soften(s, 3)


def quad(c, f, r, a, b):
    cx, cy = c
    return [(cx + r[0] * a * sa + f[0] * b * sb, cy + r[1] * a * sa + f[1] * b * sb)
            for sa, sb in ((-1, -1), (1, -1), (1, 1), (-1, 1))]


def outlined(font, text, color, outline=(0, 0, 0), ow=2):
    base = font.render(text, True, color)
    w, h = base.get_size()
    s = pygame.Surface((w + 2 * ow, h + 2 * ow), pygame.SRCALPHA)
    o = font.render(text, True, outline)
    for dx in (-ow, 0, ow):
        for dy in (-ow, 0, ow):
            if dx or dy:
                s.blit(o, (dx + ow, dy + ow))
    s.blit(base, (ow, ow))
    return s


def angle_key(a):
    return int(round(a / ANG_STEP)) % (360 // ANG_STEP)


def foliage(surf, rect, rng, density=1.0):
    n = int(rect.w * rect.h / 60 * density) + 6
    greens = [(34, 70, 40), (46, 92, 50), (62, 118, 62), (84, 140, 72), (104, 158, 84)]
    for i in range(n):
        x = rng.uniform(rect.left + 3, rect.right - 3)
        y = rng.uniform(rect.top + 3, rect.bottom - 3)
        col = greens[min(4, int(i / n * 5))]
        r = rng.uniform(3, 8)
        pygame.draw.ellipse(surf, col, (x - r, y - r * 0.6, r * 2, r * 1.2))
    for _ in range(n // 3):
        x = rng.uniform(rect.left + 3, rect.right - 3)
        y = rng.uniform(rect.top + 3, rect.bottom - 3)
        pygame.draw.line(surf, (130, 178, 100), (x, y), (x + rng.uniform(-5, 5), y + rng.uniform(-5, 5)), 2)


# =====================================================================
# SPRITES (drawn once, then cached)
# =====================================================================
def make_look(name, dept):
    rng = random.Random(name)
    female = name in LONG_HAIR
    shirts = ([(238, 236, 230), (222, 172, 182), (212, 196, 170), (36, 36, 40), (70, 118, 124), (180, 196, 222)]
              if female else
              [(238, 238, 234), (172, 196, 226), (128, 132, 140), (40, 52, 86), (34, 34, 38), (196, 186, 160)])
    look = dict(
        shirt=rng.choice(shirts),
        pants=rng.choice([(40, 42, 48), (58, 60, 68), (30, 32, 40), (88, 78, 68)]),
        skin=rng.choice([(232, 196, 164), (222, 184, 150), (210, 170, 138)]),
        hair=rng.choice([(22, 20, 20), (34, 27, 24), (52, 40, 32)]),
        long=female, trim=None,
    )
    if name == ISO_NAME:
        look.update(shirt=(36, 58, 122), trim=(240, 200, 40))
    if name == "Maria Lam":
        look.update(shirt=(52, 52, 62))
    return look


def person_sprite(look, phase, mode, size=1.0):
    """Top-down person facing +x. mode: run / type / caught."""
    s = pygame.Surface((60, 60), pygame.SRCALPHA)
    cx, cy = 28, 30
    shirt, pants, skin, hair = look["shirt"], look["pants"], look["skin"], look["hair"]
    sw = math.sin(phase)
    if mode == "run":
        for side, k in ((-1, 1), (1, -1)):
            off = 9 * sw * k
            pygame.draw.ellipse(s, pants, (cx - 6 + off, cy + side * 5 - 3.5, 14, 7))
            pygame.draw.ellipse(s, (18, 18, 20), (cx + 4 + off, cy + side * 5 - 3, 6, 6))
    elif mode == "caught":
        pygame.draw.ellipse(s, pants, (cx - 14, cy - 8, 12, 16))
    if mode == "type":
        jit = math.sin(phase * 3) * 1.2
        for side in (-1, 1):
            pygame.draw.line(s, shirt, (cx - 2, cy + side * 10), (cx + 9, cy + side * 6), 5)
            pygame.draw.circle(s, skin, (cx + 11, cy + side * 5 + jit * side), 2.6)
    elif mode == "caught":
        for side in (-1, 1):
            pygame.draw.line(s, shirt, (cx - 1, cy + side * 10), (cx + 3, cy + side * 15), 5)
            pygame.draw.circle(s, skin, (cx + 5, cy + side * 16), 2.8)
    else:
        for side, k in ((-1, -1), (1, 1)):
            off = (8 * sw * k) if mode == "run" else 0
            pygame.draw.ellipse(s, shade(shirt, 0.85), (cx - 5 + off, cy + side * 11 - 3, 11, 6))
            pygame.draw.circle(s, skin, (cx + 6 + off, cy + side * 11), 2.6)
    pygame.draw.ellipse(s, shade(shirt, 0.72), (cx - 7, cy - 12.5, 14, 25))
    pygame.draw.ellipse(s, shirt, (cx - 6, cy - 11, 11, 21))
    pygame.draw.ellipse(s, shade(shirt, 1.12), (cx - 4, cy - 8, 6, 12))
    if look.get("trim"):
        pygame.draw.ellipse(s, look["trim"], (cx - 4, cy - 12, 7, 3))
        pygame.draw.ellipse(s, look["trim"], (cx - 4, cy + 9, 7, 3))
        pygame.draw.line(s, look["trim"], (cx + 4, cy - 3), (cx + 4, cy + 3), 2)
    if look["long"]:
        pygame.draw.ellipse(s, hair, (cx - 12, cy - 7, 13, 14))
    pygame.draw.circle(s, shade(skin, 0.9), (cx + 1, cy), 7.2)
    pygame.draw.circle(s, hair, (cx - 0.5, cy), 6.9)
    pygame.draw.ellipse(s, skin, (cx + 3, cy - 4, 5, 8))
    pygame.draw.circle(s, shade(hair, 1.6), (cx - 2, cy - 2.5), 2)
    if mode == "caught":
        s.fill((150, 150, 158, 255), special_flags=pygame.BLEND_RGBA_MULT)
    if size != 1.0:
        s = pygame.transform.smoothscale(s, (int(60 * size), int(60 * size)))
    return s


class SpriteCache:
    """Each person has a small set of animation frames x 36 rotations, built on demand."""
    RUN_FRAMES = 8
    TYPE_FRAMES = 4

    def __init__(self, look):
        self.look = look
        self.base = {}
        self.rot = {}

    def get(self, mode, phase, angle):
        if mode == "run":
            f = int(phase / math.tau * self.RUN_FRAMES) % self.RUN_FRAMES
            ph = f * math.tau / self.RUN_FRAMES
            size = 1.22
        elif mode == "type":
            f = int(phase / math.tau * self.TYPE_FRAMES) % self.TYPE_FRAMES
            ph = f * math.tau / self.TYPE_FRAMES
            size = 1.22
        else:
            f, ph, size = 0, 0.0, 1.15
        ak = angle_key(angle)
        key = (mode, f, ak)
        spr = self.rot.get(key)
        if spr is None:
            bk = (mode, f)
            base = self.base.get(bk)
            if base is None:
                base = person_sprite(self.look, ph, mode, size)
                self.base[bk] = base
            spr = pygame.transform.rotate(base, -ak * ANG_STEP)
            self.rot[key] = spr
        return spr


def hunter_sprite(phase, moving):
    s = pygame.Surface((76, 76), pygame.SRCALPHA)
    cx, cy = 36, 38
    sw = math.sin(phase) if moving else 0
    coat = (34, 36, 42)
    if moving:
        for side, k in ((-1, 1), (1, -1)):
            off = 10 * sw * k
            pygame.draw.ellipse(s, (20, 20, 24), (cx - 4 + off, cy + side * 6 - 4, 16, 8))
    sway = math.sin(phase * 0.5) * 3
    pygame.draw.ellipse(s, shade(coat, 0.8), (cx - 20, cy - 13 + sway, 22, 26))
    pygame.draw.ellipse(s, (26, 26, 30), (cx - 6 - 8 * sw, cy - 18, 12, 7))
    pygame.draw.ellipse(s, coat, (cx - 9, cy - 16, 18, 32))
    pygame.draw.ellipse(s, shade(coat, 1.35), (cx - 5, cy - 11, 9, 16))
    pygame.draw.line(s, (26, 26, 30), (cx, cy + 12), (cx + 14, cy + 9), 6)
    pygame.draw.rect(s, (90, 92, 98), (cx + 12, cy + 6, 9, 5), border_radius=2)
    pygame.draw.rect(s, (255, 246, 210), (cx + 20, cy + 6, 2, 5))
    pygame.draw.circle(s, (18, 18, 20), (cx + 1, cy), 11)
    pygame.draw.circle(s, (40, 40, 46), (cx + 1, cy), 7)
    pygame.draw.circle(s, (64, 64, 72), (cx - 1, cy - 2), 3)
    return pygame.transform.smoothscale(s, (90, 90))


class HunterCache:
    FRAMES = 8

    def __init__(self):
        self.rot = {}
        self.base = {}

    def get(self, phase, moving, angle):
        f = (int(phase / math.tau * self.FRAMES) % self.FRAMES) if moving else -1
        ak = angle_key(angle)
        key = (f, ak)
        spr = self.rot.get(key)
        if spr is None:
            base = self.base.get(f)
            if base is None:
                base = hunter_sprite(f * math.tau / self.FRAMES if moving else 0, moving)
                self.base[f] = base
            spr = pygame.transform.rotate(base, -ak * ANG_STEP)
            self.rot[key] = spr
        return spr


def chair_sprite(color=(38, 38, 42)):
    s = pygame.Surface((34, 34), pygame.SRCALPHA)
    c = 17
    for i in range(5):
        a = i * 2 * math.pi / 5 + 0.3
        pygame.draw.line(s, (60, 60, 64), (c, c), (c + math.cos(a) * 14, c + math.sin(a) * 14), 3)
        pygame.draw.circle(s, (20, 20, 22), (c + math.cos(a) * 14, c + math.sin(a) * 14), 2)
    pygame.draw.rect(s, shade(color, 0.8), (c - 9, c - 9, 18, 18), border_radius=6)
    pygame.draw.rect(s, color, (c - 8, c - 8, 16, 16), border_radius=6)
    pygame.draw.rect(s, shade(color, 1.4), (c - 6, c - 6, 10, 12), border_radius=5)
    pygame.draw.rect(s, shade(color, 0.7), (c - 15, c - 10, 6, 20), border_radius=3)
    pygame.draw.rect(s, shade(color, 1.2), (c - 14, c - 8, 3, 16), border_radius=2)
    return s


class RotCache:
    def __init__(self, base):
        self.base = base
        self.rot = {}

    def get(self, angle):
        ak = angle_key(angle)
        spr = self.rot.get(ak)
        if spr is None:
            spr = pygame.transform.rotate(self.base, -ak * ANG_STEP)
            self.rot[ak] = spr
        return spr


def poop_sprite(size=26):
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size / 2
    cols = [(74, 46, 22), (96, 60, 28), (118, 76, 36)]
    for i, (rw, oy) in enumerate(((0.92, 0.18), (0.68, 0.0), (0.42, -0.18))):
        w = size * rw
        h = w * 0.62
        pygame.draw.ellipse(s, cols[i], (c - w / 2, c - h / 2 + oy * size, w, h))
        pygame.draw.ellipse(s, shade(cols[i], 1.35), (c - w / 3, c - h / 2 + oy * size + 1, w / 3, h / 3))
    pygame.draw.circle(s, (130, 86, 44), (c, c - size * 0.33), size * 0.08)
    return s


def ring_sprite(color):
    s = pygame.Surface((40, 24), pygame.SRCALPHA)
    pygame.draw.ellipse(s, color + (70,), s.get_rect())
    pygame.draw.ellipse(s, color + (230,), s.get_rect(), 2)
    return s


def star_points(cx, cy, r1, r2, n=5, rot=0.0):
    pts = []
    for i in range(n * 2):
        r = r1 if i % 2 == 0 else r2
        a = rot + i * math.pi / n
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return pts


# =====================================================================
# WORLD (static map, navigation grid, background, lightmap)
# =====================================================================
class World:
    def __init__(self):
        self.free = bytearray(GW * GH)
        self.desk_adj = bytearray(GW * GH)
        self._build_grid()
        self.nb4 = [self._nb(i, False) for i in range(GW * GH)]
        self.nb8 = [self._nb(i, True) for i in range(GW * GH)]
        self.exit_cells = [self._exit_cells(EXIT_A), self._exit_cells(EXIT_B)]
        self.exit_field = [self.bfs(c) for c in self.exit_cells]
        self.weapon_field = self.bfs([self.cell_of(*P(*WEAPON_POS))])
        self.monitors = []
        self.chair_sprite = chair_sprite()
        self.chair_sprite_blue = chair_sprite((40, 84, 196))
        self.chair_sprite_exec = chair_sprite((70, 44, 32))
        self.chair_caches = {id(s): RotCache(s) for s in
                             (self.chair_sprite, self.chair_sprite_blue, self.chair_sprite_exec)}
        self.bg = self._build_background()
        self.light = self._build_lightmap()
        self.minimap, self.mm_scale = self._build_minimap()
        # cached glows (additive)
        self.exit_glows = [radial(70, 40, (30, int(110 + 40 * k / 5), 60)) for k in range(6)]
        self.weapon_glows = [radial(90, 90, (int(90 * k), int(64 * k), int(20 * k)))
                             for k in (0.2, 0.36, 0.52, 0.68, 0.84, 1.0)]
        self.flash_glow = radial(240, 240, (255, 255, 255))

    # ---------- grid ----------
    def _mark(self, r, val, arr=None):
        arr = self.free if arr is None else arr
        for gx in range(max(0, r.left // CELL - 1), min(GW, r.right // CELL + 2)):
            cx = gx * CELL + CELL / 2
            if not (r.left <= cx < r.right):
                continue
            for gy in range(max(0, r.top // CELL - 1), min(GH, r.bottom // CELL + 2)):
                cy = gy * CELL + CELL / 2
                if r.top <= cy < r.bottom:
                    arr[gy * GW + gx] = val

    def _build_grid(self):
        for fr in FLOOR:
            self._mark(RP(*fr), 1)
        blockers = WALLS_WINDOW + WALLS_SOLID + GLASS + [o[1:] for o in OBST]
        for b in blockers:
            self._mark(RP(*b).inflate(INFLATE * 2, INFLATE * 2), 0)
        for o in OBST:
            if o[0] in ("desk", "cluster", "execdesk", "reception"):
                self._mark(RP(*o[1:]).inflate(INFLATE * 2 + 34, INFLATE * 2 + 34), 1, self.desk_adj)

    def _nb(self, i, diag):
        if not self.free[i]:
            return ()
        x, y = i % GW, i // GW
        out = []
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < GW and 0 <= ny < GH and self.free[ny * GW + nx]:
                out.append(ny * GW + nx)
        if diag:
            for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                nx, ny = x + dx, y + dy
                if (0 <= nx < GW and 0 <= ny < GH and self.free[ny * GW + nx]
                        and self.free[y * GW + nx] and self.free[ny * GW + x]):
                    out.append(ny * GW + nx)
        return tuple(out)

    def _exit_cells(self, xr):
        x1, _ = P(xr[0], 0)
        x2, _ = P(xr[1], 0)
        out = []
        for gx in range(GW):
            for gy in range(GH):
                cx, cy = gx * CELL + CELL / 2, gy * CELL + CELL / 2
                if x1 <= cx <= x2 and cy < EXIT_Y and self.free[gy * GW + gx]:
                    out.append(gy * GW + gx)
        return out

    def cell_of(self, x, y):
        gx = int(clamp(x // CELL, 0, GW - 1))
        gy = int(clamp(y // CELL, 0, GH - 1))
        return gy * GW + gx

    def center(self, i):
        return (i % GW) * CELL + CELL / 2, (i // GW) * CELL + CELL / 2

    def is_free(self, x, y):
        if x < 0 or y < 0 or x >= WORLD_W or y >= WORLD_H:
            return False
        return self.free[self.cell_of(x, y)] == 1

    def nearest_free(self, i):
        if self.free[i]:
            return i
        x0, y0 = i % GW, i // GW
        for r in range(1, 8):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    nx, ny = x0 + dx, y0 + dy
                    if 0 <= nx < GW and 0 <= ny < GH and self.free[ny * GW + nx]:
                        return ny * GW + nx
        return i

    def bfs(self, sources, max_depth=None):
        INF = 10 ** 6
        dist = [INF] * (GW * GH)
        dq = deque()
        for s in sources:
            if self.free[s]:
                dist[s] = 0
                dq.append(s)
        nb4 = self.nb4
        while dq:
            c = dq.popleft()
            d = dist[c] + 1
            if max_depth is not None and d > max_depth:
                continue
            for n in nb4[c]:
                if dist[n] > d:
                    dist[n] = d
                    dq.append(n)
        return dist

    # ---------- background ----------
    def _carpet(self, rng):
        T = 40
        tiles = []
        for grey in (False, False, False, False, True, True):
            t = pygame.Surface((T, T))
            base = (172, 174, 180) if grey else (36, 46, 82)
            t.fill(shade(base, rng.uniform(0.95, 1.04)))
            for _ in range(140):
                x, y = rng.uniform(0, T), rng.uniform(0, T)
                k = rng.choice((0.78, 0.86, 1.15, 1.3))
                pygame.draw.line(t, shade(base, k), (x, y), (x + rng.uniform(2, 6), y + rng.uniform(-0.6, 0.6)))
            pygame.draw.rect(t, shade(base, 0.82), (0, 0, T, T), 1)
            tiles.append(t)
        carpet = pygame.Surface((WORLD_W, WORLD_H))
        gx, gy = WORLD_W // T + 1, WORLD_H // T + 1
        grey_spots = set()
        for _ in range(int(gx * gy * 0.016)):
            x, y = rng.randrange(gx), rng.randrange(gy)
            grey_spots.add((x, y))
            grey_spots.add((x + 1, y + 1) if rng.random() < 0.5 else (x + 1, y - 1))
        for x in range(gx):
            for y in range(gy):
                t = tiles[rng.choice((4, 5))] if (x, y) in grey_spots else tiles[rng.randrange(4)]
                carpet.blit(t, (x * T, y * T))
        return carpet

    def _workstation(self, bg, pos, facing, rng, occupied, owner=None):
        a = math.radians(facing)
        f = (math.cos(a), math.sin(a))
        r = (-f[1], f[0])
        x, y = pos
        mon = (x + f[0] * 50, y + f[1] * 50)
        n_mon = 2 if occupied and rng.random() < 0.7 else 1
        offs = (-19, 19) if n_mon == 2 else (0,)
        for o in offs:
            c = (mon[0] + r[0] * o, mon[1] + r[1] * o)
            pygame.draw.polygon(bg, (70, 72, 78), quad((c[0] + f[0] * 5, c[1] + f[1] * 5), f, r, 5, 3))
            pygame.draw.polygon(bg, (20, 20, 24), quad(c, f, r, 17, 2.6))
            pygame.draw.polygon(bg, (58, 66, 84), quad((c[0] - f[0] * 2, c[1] - f[1] * 2), f, r, 16, 0.8))
            self.monitors.append(c)
        kb = (x + f[0] * 34, y + f[1] * 34)
        pygame.draw.polygon(bg, (150, 150, 156), quad(kb, f, r, 14, 4.6))
        pygame.draw.polygon(bg, (208, 208, 212), quad(kb, f, r, 13, 3.6))
        for k in (-2, 0, 2):
            p1 = (kb[0] + r[0] * -11 + f[0] * k, kb[1] + r[1] * -11 + f[1] * k)
            p2 = (kb[0] + r[0] * 11 + f[0] * k, kb[1] + r[1] * 11 + f[1] * k)
            pygame.draw.line(bg, (176, 176, 182), p1, p2)
        side = rng.choice((-1, 1))
        ms = (kb[0] + r[0] * 22 * side, kb[1] + r[1] * 22 * side)
        pygame.draw.circle(bg, (60, 60, 66), ms, 3.4)
        pygame.draw.circle(bg, (120, 120, 128), ms, 1.5)
        if not occupied:
            return
        for _ in range(rng.randint(1, 4)):
            c = (x + f[0] * rng.uniform(30, 44) + r[0] * rng.uniform(-34, 34) * -side,
                 y + f[1] * rng.uniform(30, 44) + r[1] * rng.uniform(-34, 34) * -side)
            ang = rng.uniform(-0.5, 0.5)
            ff = (math.cos(a + ang), math.sin(a + ang))
            rr = (-ff[1], ff[0])
            pygame.draw.polygon(bg, (190, 190, 186), quad((c[0] + 1, c[1] + 1), ff, rr, 7, 9))
            pygame.draw.polygon(bg, (246, 246, 242), quad(c, ff, rr, 7, 9))
            for k in range(-5, 6, 3):
                pygame.draw.line(bg, (180, 182, 190), (c[0] + ff[0] * k - rr[0] * 4, c[1] + ff[1] * k - rr[1] * 4),
                                 (c[0] + ff[0] * k + rr[0] * 4, c[1] + ff[1] * k + rr[1] * 4))
        bc = (x + f[0] * 40 - r[0] * 38 * side, y + f[1] * 40 - r[1] * 38 * side)
        for k, col in enumerate(rng.sample([(30, 60, 140), (150, 30, 40), (30, 30, 34), (220, 200, 60), (40, 110, 70)], 3)):
            pygame.draw.polygon(bg, col, quad((bc[0] + r[0] * k * 4, bc[1] + r[1] * k * 4), f, r, 1.8, 9))
        mug = (x + f[0] * 26 + r[0] * 30 * side, y + f[1] * 26 + r[1] * 30 * side)
        mc = (30, 50, 90) if owner == ISO_NAME else rng.choice([(236, 236, 230), (40, 40, 44), (180, 60, 50)])
        pygame.draw.circle(bg, shade(mc, 0.7), mug, 4.6)
        pygame.draw.circle(bg, mc, mug, 3.8)
        pygame.draw.circle(bg, (70, 44, 26), mug, 2.4)
        if rng.random() < 0.25:
            pc = (x + f[0] * 46 + r[0] * 40 * side, y + f[1] * 46 + r[1] * 40 * side)
            pygame.draw.circle(bg, (200, 196, 186), pc, 6)
            foliage(bg, pygame.Rect(pc[0] - 7, pc[1] - 7, 14, 14), rng, 0.6)

    def _desk_top(self, bg, r, col=(220, 212, 194)):
        pygame.draw.rect(bg, shade(col, 0.82), r, border_radius=3)
        pygame.draw.rect(bg, col, r.inflate(-3, -3), border_radius=3)
        pygame.draw.line(bg, shade(col, 1.06), (r.left + 2, r.top + 2), (r.right - 3, r.top + 2))

    def _build_background(self):
        rng = random.Random(2026)
        bg = pygame.Surface((WORLD_W, WORLD_H))
        bg.fill((14, 17, 24))
        for _ in range(160):   # neighbouring rooftops seen from above
            w, h = rng.uniform(60, 260), rng.uniform(50, 200)
            x, y = rng.uniform(-50, WORLD_W), rng.uniform(-50, WORLD_H)
            base = rng.choice([(30, 33, 40), (36, 38, 44), (26, 28, 34)])
            pygame.draw.rect(bg, shade(base, 0.7), (x + 6, y + 8, w, h))
            pygame.draw.rect(bg, base, (x, y, w, h))
            pygame.draw.rect(bg, shade(base, 1.3), (x, y, w, h), 2)
            for _ in range(rng.randint(0, 4)):
                pygame.draw.rect(bg, (58, 60, 66), (x + rng.uniform(5, w - 25), y + rng.uniform(5, h - 25), 18, 14))
            if rng.random() < 0.5:
                pygame.draw.circle(bg, (120, 96, 50), (x + rng.uniform(4, w - 4), y + rng.uniform(4, h - 4)), 2)
        lob = RP(29, 150, 1174, 186)
        pygame.draw.rect(bg, (122, 120, 116), lob)
        for x in range(lob.left, lob.right, 48):
            pygame.draw.line(bg, (104, 102, 98), (x, lob.top), (x, lob.bottom))
        pygame.draw.line(bg, (104, 102, 98), (lob.left, lob.top + 24), (lob.right, lob.top + 24))
        carpet = self._carpet(rng)
        for fr in FLOOR:
            r = RP(*fr)
            bg.blit(carpet, r.topleft, r)
        sh = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
        for o in OBST:
            r = RP(*o[1:])
            off = 10 if o[0] in ("server", "cabinet", "pantry", "column", "plantercab", "planter") else 6
            pygame.draw.rect(sh, (0, 0, 0, 90), r.move(off * 0.6, off), border_radius=4)
        for w in GLASS:
            pygame.draw.rect(sh, (0, 0, 0, 40), RP(*w).move(3, 5))
        bg.blit(soften(sh, 4), (0, 0))
        for kind, *pr in OBST:
            r = RP(*pr)
            getattr(self, "_draw_" + kind)(bg, r, rng)
        for name, dept, x, y, fa, pts in STAFF:
            self._workstation(bg, P(x, y), fa, rng, True, name)
        for x, y, fa in VACANT_SEATS:
            self._workstation(bg, P(x, y), fa, rng, False)
        self._draw_walls(bg, rng)
        font = pygame.font.Font(None, 18)
        for txt, (x, y) in (("MEETING ROOM", (806, 300)), ("SERVER ROOM", (96, 325)), ("PANTRY", (440, 236)),
                            ("RECEPTION", (562, 276)), ("LOGISTICS", (225, 572)), ("SHIPPING", (404, 572)),
                            ("HEAD OF GAC HK LTD", (592, 572)), ("ACCOUNT", (1118, 294)), ("VACANT", (84, 572))):
            t = font.render(txt, True, (200, 206, 214))
            t.set_alpha(120)
            wx, wy = P(x, y)
            bg.blit(t, (wx - t.get_width() / 2, wy - t.get_height() / 2))
        return bg

    def _draw_desk(self, bg, r, rng):
        self._desk_top(bg, r)

    def _draw_cluster(self, bg, r, rng):
        self._desk_top(bg, r)
        cx = r.centerx
        pygame.draw.rect(bg, (96, 110, 130), (cx - 3, r.top + 3, 6, r.h - 6), border_radius=2)
        pygame.draw.line(bg, (150, 164, 184), (cx - 2, r.top + 4), (cx - 2, r.bottom - 5))
        n = 3 if r.h > 200 else 2
        for k in range(1, n):
            y = r.top + r.h * k / n
            pygame.draw.line(bg, (206, 200, 186), (r.left + 3, y), (r.right - 3, y), 2)

    def _draw_execdesk(self, bg, r, rng):
        self._desk_top(bg, r, (96, 66, 46))
        pygame.draw.line(bg, (130, 96, 70), (r.left + 6, r.top + 8), (r.right - 30, r.top + 8))
        self._draw_chair_static(bg, (r.centerx - 30, r.top - 30), 90)
        self._draw_chair_static(bg, (r.centerx + 30, r.top - 30), 90)

    def _draw_chair_static(self, bg, pos, facing, spr=None):
        spr = pygame.transform.rotate(spr or self.chair_sprite, -facing)
        bg.blit(spr, (pos[0] - spr.get_width() / 2, pos[1] - spr.get_height() / 2))

    def _draw_table(self, bg, r, rng):
        for i in range(2):
            x = r.left + r.w * (0.3 + 0.4 * i)
            self._draw_chair_static(bg, (x, r.top - 14), 90)
            self._draw_chair_static(bg, (x, r.bottom + 14), -90)
        self._desk_top(bg, r, (238, 238, 234))
        for _ in range(3):
            c = (rng.uniform(r.left + 12, r.right - 12), rng.uniform(r.top + 12, r.bottom - 12))
            pygame.draw.polygon(bg, (246, 246, 242), quad(c, (1, 0), (0, 1), 9, 7))

    def _draw_mtable(self, bg, r, rng):
        for i in range(5):
            x = r.left + 22 + i * (r.w - 44) / 4
            self._draw_chair_static(bg, (x, r.top - 16), 90)
            self._draw_chair_static(bg, (x, r.bottom + 16), -90)
        self._draw_chair_static(bg, (r.left - 16, r.centery), 0)
        self._desk_top(bg, r, (170, 132, 92))
        for k in range(6, r.h - 4, 7):
            pygame.draw.line(bg, (156, 118, 80), (r.left + 4, r.top + k), (r.right - 5, r.top + k))
        pygame.draw.circle(bg, (30, 30, 34), r.center, 9)
        tv = RP(912 - 8, 225, 912 - 4, 285)
        pygame.draw.rect(bg, (16, 16, 18), tv)

    def _draw_reception(self, bg, r, rng):
        self._desk_top(bg, r, (236, 232, 222))
        pygame.draw.rect(bg, (200, 194, 180), (r.left, r.top, r.w, 10), border_radius=3)
        font = pygame.font.Font(None, 22)
        t = font.render("GAC", True, (0, 64, 128))
        bg.blit(t, (r.centerx - t.get_width() / 2, r.top - 1))

    def _draw_pantry(self, bg, r, rng):
        pygame.draw.rect(bg, (214, 208, 194), r)
        lk = RP(95, 192, 242, 226)
        for x in range(lk.left, lk.right, 36):
            pygame.draw.rect(bg, (196, 190, 176), (x + 1, lk.top + 1, 34, lk.h - 2))
            pygame.draw.rect(bg, (170, 164, 150), (x + 1, lk.top + 1, 34, lk.h - 2), 1)
            pygame.draw.circle(bg, (120, 120, 120), (x + 28, lk.centery), 2)
        ct = RP(244, 192, 555, 226)
        pygame.draw.rect(bg, (150, 150, 148), ct)
        for _ in range(250):
            pygame.draw.circle(bg, rng.choice([(170, 170, 168), (134, 134, 132)]),
                               (rng.uniform(ct.left, ct.right), rng.uniform(ct.top, ct.bottom)), 1)
        sink = RP(290, 197, 320, 220)
        pygame.draw.rect(bg, (186, 190, 194), sink, border_radius=5)
        pygame.draw.rect(bg, (120, 124, 130), sink.inflate(-8, -8), border_radius=4)
        pygame.draw.rect(bg, (24, 24, 26), RP(350, 196, 372, 214), border_radius=3)
        pygame.draw.circle(bg, (200, 60, 50), P(366, 200), 2)
        pygame.draw.rect(bg, (60, 60, 64), RP(400, 196, 432, 216), border_radius=2)
        pygame.draw.rect(bg, (30, 34, 40), RP(404, 199, 422, 213))
        pygame.draw.circle(bg, (236, 236, 236), P(468, 208), 13)
        pygame.draw.circle(bg, (110, 170, 220), P(468, 208), 8)
        fr = RP(515, 192, 555, 226)
        pygame.draw.rect(bg, (176, 180, 186), fr)
        pygame.draw.line(bg, (140, 144, 150), (fr.left, fr.centery), (fr.right, fr.centery), 2)

    def _draw_sofa(self, bg, r, rng):
        pygame.draw.rect(bg, (84, 86, 92), r, border_radius=8)
        pygame.draw.rect(bg, (104, 106, 114), (r.left + 10, r.top + 10, r.w - 20, r.h - 12), border_radius=5)
        for k in range(1, 3):
            x = r.left + 10 + (r.w - 20) * k / 3
            pygame.draw.line(bg, (84, 86, 92), (x, r.top + 12), (x, r.bottom - 4), 2)
        pygame.draw.rect(bg, (178, 110, 60), (r.left + 16, r.top + 12, 16, 12), border_radius=4)
        pygame.draw.rect(bg, (60, 62, 68), (r.left + r.w / 2 - 40, r.bottom + 10, 26, 26), border_radius=13)

    def _draw_printer(self, bg, r, rng):
        pygame.draw.rect(bg, (210, 212, 210), r, border_radius=3)
        pygame.draw.rect(bg, (64, 66, 70), (r.left + 6, r.top + 5, r.w * 0.45, r.h - 10), border_radius=2)
        pygame.draw.rect(bg, (246, 246, 244), (r.right - r.w * 0.42, r.top + 6, r.w * 0.34, r.h - 12))
        pygame.draw.circle(bg, (60, 220, 120), (r.left + 10, r.bottom - 6), 2)

    def _draw_server(self, bg, r, rng):
        pygame.draw.rect(bg, (44, 46, 52), r)
        pygame.draw.rect(bg, (120, 124, 130), r, 4)
        for i in range(4):
            rr = pygame.Rect(r.left + 16 + i * 56, r.top + 22, 40, r.h - 44)
            pygame.draw.rect(bg, (16, 16, 20), rr)
            for y in range(rr.top + 4, rr.bottom - 4, 6):
                pygame.draw.line(bg, (40, 42, 48), (rr.left + 3, y), (rr.right - 4, y))

    def _draw_filing(self, bg, r, rng):
        pygame.draw.rect(bg, (150, 152, 156), r, border_radius=2)
        pygame.draw.rect(bg, (176, 178, 182), r.inflate(-6, -6), border_radius=2)

    def _draw_cabinet(self, bg, r, rng):
        pygame.draw.rect(bg, (206, 198, 178), r, border_radius=2)
        pygame.draw.rect(bg, (226, 219, 200), r.inflate(-4, -4), border_radius=2)
        for _ in range(3):
            c = (rng.uniform(r.left + 8, r.right - 8), rng.uniform(r.top + 8, r.bottom - 8))
            pygame.draw.polygon(bg, rng.choice([(40, 70, 140), (240, 240, 236), (150, 40, 40)]),
                                quad(c, (0, 1), (1, 0), 6, 8))

    def _draw_shelf(self, bg, r, rng):
        pygame.draw.rect(bg, (70, 72, 78), r)
        for y in range(r.top + 4, r.bottom - 10, 22):
            pygame.draw.rect(bg, (168, 132, 88), (r.left + 3, y, r.w - 6, 18))
            pygame.draw.line(bg, (190, 160, 110), (r.left + 3, y + 9), (r.right - 4, y + 9))

    def _draw_planter(self, bg, r, rng):
        pygame.draw.rect(bg, (210, 202, 184), r, border_radius=2)
        pygame.draw.rect(bg, (60, 46, 34), r.inflate(-8, -8))
        foliage(bg, r.inflate(4, 4), rng, 1.2)

    def _draw_plantercab(self, bg, r, rng):
        self._draw_planter(bg, r, rng)

    def _draw_column(self, bg, r, rng):
        pygame.draw.rect(bg, (214, 214, 210), r)
        pygame.draw.rect(bg, (240, 240, 236), r.inflate(-4, -4))

    def _draw_bin(self, bg, r, rng):
        pygame.draw.rect(bg, (70, 72, 78), r, border_radius=6)
        pygame.draw.rect(bg, (150, 152, 158), r.inflate(-6, -6), border_radius=5)
        pygame.draw.line(bg, (60, 60, 64), (r.left + 8, r.centery), (r.right - 8, r.centery), 2)

    def _draw_walls(self, bg, rng):
        for w in WALLS_SOLID:
            r = RP(*w)
            pygame.draw.rect(bg, (90, 90, 94), r)
            pygame.draw.rect(bg, (214, 212, 206), r.inflate(-3, -3))
        for w in WALLS_WINDOW:
            r = RP(*w)
            pygame.draw.rect(bg, (48, 50, 56), r)
            horiz = r.w > r.h
            inner = r.inflate(0, -6) if horiz else r.inflate(-6, 0)
            pygame.draw.rect(bg, (92, 124, 146), inner)
            length = r.w if horiz else r.h
            for k in range(0, length, 74):
                if horiz:
                    pygame.draw.rect(bg, (34, 36, 40), (r.left + k, r.top, 4, r.h))
                    if rng.random() < 0.55:
                        pygame.draw.rect(bg, (112, 114, 120), (r.left + k + 4, inner.top, 70, inner.h))
                else:
                    pygame.draw.rect(bg, (34, 36, 40), (r.left, r.top + k, r.w, 4))
                    if rng.random() < 0.55:
                        pygame.draw.rect(bg, (112, 114, 120), (inner.left, r.top + k + 4, inner.w, 70))
        gl = pygame.Surface((WORLD_W, WORLD_H), pygame.SRCALPHA)
        for w in GLASS:
            r = RP(*w)
            pygame.draw.rect(gl, (200, 226, 236, 130), r)
            horiz = r.w > r.h
            length = r.w if horiz else r.h
            for k in range(2, length - 2, 5):
                if rng.random() < 0.55:
                    if horiz:
                        pygame.draw.rect(gl, (250, 252, 255, 150), (r.left + k, r.top + 2, 3, 3))
                    else:
                        pygame.draw.rect(gl, (250, 252, 255, 150), (r.left + 2, r.top + k, 3, 3))
            pygame.draw.rect(gl, (150, 158, 166, 255), r, 1)
            for k in range(0, length, 120):
                if horiz:
                    pygame.draw.rect(gl, (120, 126, 134, 255), (r.left + k, r.top, 3, r.h))
                else:
                    pygame.draw.rect(gl, (120, 126, 134, 255), (r.left, r.top + k, r.w, 3))
        bg.blit(gl, (0, 0))
        font = pygame.font.Font(None, 15)
        for (x1, x2), double in ((EXIT_A, False), (EXIT_B, True)):
            a, _ = P(x1, 0)
            b, wy = P(x2, 186)
            leaves = ((a, (b - a) / 2, 1), (b, (b - a) / 2, -1)) if double else ((a, b - a, 1),)
            for hx, ln, sgn in leaves:
                pygame.draw.line(bg, (160, 182, 196), (hx, wy), (hx, wy - ln * 0.8), 4)
                pygame.draw.arc(bg, (110, 116, 124), (hx - ln, wy - ln, ln * 2, ln * 2),
                                0 if sgn > 0 else math.pi / 2, math.pi / 2 if sgn > 0 else math.pi, 1)
            cx = (a + b) / 2
            sign = pygame.Rect(0, 0, 34, 12)
            sign.center = (cx, wy + 2)
            pygame.draw.rect(bg, (20, 150, 80), sign, border_radius=2)
            t = font.render("EXIT", True, (240, 255, 244))
            bg.blit(t, (sign.centerx - t.get_width() / 2, sign.centery - t.get_height() / 2))
        self.exit_sign_pos = [((P(EXIT_A[0], 0)[0] + P(EXIT_A[1], 0)[0]) / 2, P(0, 186)[1] + 2),
                              ((P(EXIT_B[0], 0)[0] + P(EXIT_B[1], 0)[0]) / 2, P(0, 186)[1] + 2)]

    # ---------- lighting (built once at full size, stored at 1/LS size) ----------
    def _build_lightmap(self):
        lm = pygame.Surface((WORLD_W, WORLD_H))
        lm.fill((168, 170, 182))
        off = [RP(*r) for r in LIGHTS_OFF]
        strip = radial(300, 190, (90, 88, 80), power=1.5)
        core = radial(130, 40, (30, 30, 28), power=1.2)
        for fr in FLOOR[:2]:
            r = RP(*fr)
            for x in range(r.left + 100, r.right - 40, 190):
                for y in range(r.top + 80, r.bottom - 30, 160):
                    if any(o.collidepoint(x, y) for o in off):
                        continue
                    lm.blit(strip, (x - 150, y - 95), special_flags=pygame.BLEND_RGB_ADD)
                    lm.blit(core, (x - 65, y - 20), special_flags=pygame.BLEND_RGB_ADD)
        for o in off:      # vacant room darker than the base
            lm.fill((96, 96, 110), o)
        warm = (64, 40, 16)
        for w in WALLS_WINDOW[1:]:
            r = RP(*w)
            horiz = r.w > r.h
            for i in range(36):
                k = (1 - i / 36) ** 1.6
                col = tuple(int(c * k) for c in warm)
                if horiz:
                    y = r.top - 4 * (i + 1) if w[1] > 380 else r.bottom + 4 * i
                    band = pygame.Rect(r.left, y, r.w, 4)
                else:
                    x = r.left - 4 * (i + 1)
                    band = pygame.Rect(x, r.top, 4, r.h)
                lm.fill(col, band, special_flags=pygame.BLEND_RGB_ADD)
        glow = radial(90, 90, (34, 42, 60))
        for m in self.monitors:
            lm.blit(glow, (m[0] - 45, m[1] - 45), special_flags=pygame.BLEND_RGB_ADD)
        g = radial(160, 120, (30, 90, 50))
        for p in self.exit_sign_pos:
            lm.blit(g, (p[0] - 80, p[1] - 50), special_flags=pygame.BLEND_RGB_ADD)
        return pygame.transform.smoothscale(lm, (WORLD_W // LS, WORLD_H // LS))

    def _build_minimap(self):
        w = 300
        sc = w / WORLD_W
        h = int(WORLD_H * sc)
        mm = pygame.Surface((w, h), pygame.SRCALPHA)
        mm.fill((10, 12, 18, 210))
        for i in range(GW * GH):
            if self.free[i]:
                x, y = self.center(i)
                pygame.draw.rect(mm, (52, 62, 92, 255), (x * sc - 1, y * sc - 1, CELL * sc + 1, CELL * sc + 1))
        for w_ in WALLS_WINDOW + WALLS_SOLID + GLASS:
            r = RP(*w_)
            pygame.draw.rect(mm, (170, 180, 196, 255), (r.x * sc, r.y * sc, max(1, r.w * sc), max(1, r.h * sc)))
        for cells in self.exit_cells:
            for c in cells:
                x, y = self.center(c)
                pygame.draw.rect(mm, (40, 220, 120, 255), (x * sc - 1, y * sc - 1, 3, 3))
        pygame.draw.rect(mm, (120, 130, 150, 255), mm.get_rect(), 1)
        return mm, sc


# =====================================================================
# SHARED VISUAL ASSETS (built once, reused by every round)
# =====================================================================
class Assets:
    def __init__(self, fonts):
        self.f = fonts
        self.shadow = pygame.Surface((30, 18), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow, (0, 0, 0, 80), self.shadow.get_rect())
        self.hshadow = pygame.transform.scale(self.shadow, (44, 26))
        self.rings = {d: ring_sprite(v["color"]) for d, v in DEPTS.items()}
        self.hunter = HunterCache()
        self.poop16 = poop_sprite(16)
        self.poop22 = RotCache(poop_sprite(22))
        self.poop26 = poop_sprite(26)
        self.cone = self._make_cone()
        self.cone_rot = {}
        self.lv = pygame.Surface((SCREEN_W // LS + 2, SCREEN_H // LS + 2))
        self.lv_big = pygame.Surface((SCREEN_W + 2 * LS, SCREEN_H + 2 * LS))
        self.vig = {}
        self.red_vig = self._red_vignette()
        self.weak = outlined(fonts["huge"], "YOU ARE WEAK!", (255, 46, 46), (30, 0, 0), 5)
        self.pow_ = outlined(fonts["big"], "POW!", (255, 230, 80), (60, 20, 0), 4)
        self.stunned = outlined(fonts["mid"], "STUNNED", (255, 220, 220), (40, 0, 0), 3)
        self.alert = fonts["alert"].render("!", True, (255, 70, 60))
        self.love = outlined(fonts["huge"], "I love you", (255, 150, 190), (90, 20, 50), 3)
        self.love_glow = soften(self.love, 6)

    def _make_cone(self):
        R = 330 // LS
        s = pygame.Surface((2 * R, 2 * R))
        s.fill((0, 0, 0))
        tmp = pygame.Surface((2 * R, 2 * R))
        for i in range(18):
            ang = math.radians(32 - i * 1.2)
            ln = R * (1 - i * 0.035)
            pts = [(R, R), (R + math.cos(-ang) * ln, R + math.sin(-ang) * ln),
                   (R + ln, R), (R + math.cos(ang) * ln, R + math.sin(ang) * ln)]
            tmp.fill((0, 0, 0))
            pygame.draw.polygon(tmp, (6, 6, 5), pts)
            s.blit(tmp, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        s.blit(radial(120 // LS, 120 // LS, (40, 38, 34)), (R - 60 // LS, R - 60 // LS),
               special_flags=pygame.BLEND_RGB_ADD)
        return soften(s, 3)

    def cone_at(self, angle):
        ak = angle_key(angle)
        c = self.cone_rot.get(ak)
        if c is None:
            c = pygame.transform.rotate(self.cone, -ak * ANG_STEP)
            self.cone_rot[ak] = c
        return c

    def vignette(self, strength):
        v = self.vig.get(strength)
        if v is None:
            v = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            for i in range(40):
                k = i / 40
                a = int(strength * (1 - k) ** 2)
                pygame.draw.rect(v, (0, 0, 0, a), (i * 8, i * 5, SCREEN_W - i * 16, SCREEN_H - i * 10), 8)
            v = soften(v, 4)
            self.vig[strength] = v
        return v

    def _red_vignette(self):
        v = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        for i in range(40):
            k = i / 40
            a = int(220 * (1 - k) ** 2)
            pygame.draw.rect(v, (150, 0, 0, a), (i * 8, i * 5, SCREEN_W - i * 16, SCREEN_H - i * 10), 8)
        return soften(v, 4)


# =====================================================================
# ENTITIES
# =====================================================================
class Chair:
    def __init__(self, x, y, facing, cache):
        self.x, self.y, self.facing = x, y, facing
        self.vx = self.vy = self.spin = 0.0
        self.cache = cache

    def update(self, dt, world):
        if abs(self.vx) + abs(self.vy) < 2:
            return
        nx, ny = self.x + self.vx * dt, self.y + self.vy * dt
        if world.is_free(nx, ny):
            self.x, self.y = nx, ny
        else:
            self.vx *= -0.3
            self.vy *= -0.3
        self.facing += self.spin * dt
        damp = math.exp(-4.0 * dt)
        self.vx *= damp
        self.vy *= damp
        self.spin *= damp


_SPRITE_CACHES = {}


class Agent:
    def __init__(self, data, chair):
        name, dept, x, y, facing, pts = data
        self.name, self.dept, self.points = name, dept, pts
        self.t = DEPTS[dept]
        self.x, self.y = P(x, y)
        self.facing = facing
        self.angle = facing
        self.chair = chair
        self.state = "seated"
        self.react_t = 0.0
        self.replan_t = 0.0
        self.target = None
        self.prev_cell = None
        self.exit_choice = 0
        self.vx = self.vy = 0.0
        self.phase = random.uniform(0, 6)
        if name not in _SPRITE_CACHES:
            _SPRITE_CACHES[name] = SpriteCache(make_look(name, dept))
        self.sprites = _SPRITE_CACHES[name]
        self.shields = 2 if name == ISO_NAME else 0
        self.has_poop = False
        self.seek_weapon = False
        self.announced = False
        self.invuln = 0.0
        self.boost_t = 0.0
        self.dash_used = False
        self.dash_t = 0.0
        self.alert_mark = 0.0
        self.punch_t = 0.0
        self.taunt_t = 0.0
        self.caught_angle = 0.0
        self.label = None
        self.swipe_t = 0.0
        self.swipe_total = 1.0
        self.swiped = False


class Hunter:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.vx = self.vy = 0.0
        self.kx = self.ky = 0.0          # knock-back velocity
        self.angle = 90.0
        self.phase = 0.0
        self.stun_t = 0.0
        self.blind_t = 0.0
        self.sprint_t = 0.0
        self.sprint_cd = 0.0


# =====================================================================
# GAME
# =====================================================================
class Game:
    def __init__(self, world, assets, best):
        self.w = world
        self.a = assets
        self.f = assets.f
        self.best = best
        self.bg = world.bg.copy()
        self.time_left = GAME_TIME
        self.elapsed = 0.0
        self.score = 0
        self.combo = 0
        self.last_catch = -99
        self.caught, self.escaped = [], []
        self.events = []
        self.popups = []
        self.papers = []
        self.flashes = []
        self.projectiles = []
        self.shake = 0.0
        self.shake_amp = 12
        self.love_t = 0.0
        self.love_agent = None
        self.love_dark = None
        self.weak_t = 0.0
        self.splat = None
        self.alarm = False
        self.intro_t = 1.3
        self.over_t = None
        self.finished = False
        self.show_names = True
        self.weapon = {"x": P(*WEAPON_POS)[0], "y": P(*WEAPON_POS)[1], "taken": False}
        hx, hy = P(666, 172)
        self.h = Hunter(hx, hy)
        self.hfield = world.bfs([world.cell_of(hx, hy)])
        self.hfield_t = 0.0
        self.chairs = []
        self.agents = []
        for data in STAFF:
            spr = world.chair_sprite_blue if data[0] == ISO_NAME else (
                world.chair_sprite_exec if data[0] == "Maria Lam" else world.chair_sprite)
            c = Chair(*P(data[2], data[3]), data[4], world.chair_caches[id(spr)])
            self.chairs.append(c)
            ag = Agent(data, c)
            ag.label = self._make_label(ag.name, ag.t["color"])
            self.agents.append(ag)
        for x, y, fa in VACANT_SEATS:
            self.chairs.append(Chair(*P(x, y), fa, world.chair_caches[id(world.chair_sprite)]))

    # ---------- helpers ----------
    def _make_label(self, name, col):
        t = self.f["tag"].render(name, True, (236, 238, 242))
        s = pygame.Surface((t.get_width() + 14, t.get_height() + 4), pygame.SRCALPHA)
        pygame.draw.rect(s, (12, 14, 20, 180), s.get_rect(), border_radius=4)
        pygame.draw.circle(s, col, (6, s.get_height() / 2), 3)
        s.blit(t, (11, 2))
        return s

    def event(self, text, col=(230, 232, 236)):
        self.events.append([self.f["small"].render(text, True, col), 5.0])
        self.events = self.events[-5:]

    def popup(self, text, x, y, col, size="pop", dur=1.1, surf=None):
        s = surf.copy() if surf is not None else outlined(self.f[size], text, col)
        self.popups.append(dict(s=s, x=x, y=y, t=0.0, dur=dur))

    def active_agents(self):
        return [a for a in self.agents if a.state in ("seated", "alerted", "flee")]

    # ---------- update ----------
    def update(self, dt, keys):
        if self.love_t > 0:
            self.love_t -= dt
            return
        self.shake = max(0.0, self.shake - dt)
        self.weak_t = max(0.0, self.weak_t - dt)
        for e in self.events:
            e[1] -= dt
        self.events = [e for e in self.events if e[1] > 0]
        for p in self.popups:
            p["t"] += dt
        self.popups = [p for p in self.popups if p["t"] < p["dur"]]
        for fl in self.flashes:
            fl[3] -= dt
        self.flashes = [f for f in self.flashes if f[3] > 0]

        if self.over_t is not None:
            self.over_t -= dt
            if self.over_t <= 0:
                self.finished = True
            self._update_world_objects(dt)
            return

        h = self.h
        if self.intro_t > 0:
            self.intro_t -= dt
            h.vx, h.vy = 0.0, 120.0
            h.y += h.vy * dt
            h.angle = 90
            h.phase += dt * 11
        else:
            self.elapsed += dt
            self.time_left = max(0.0, self.time_left - dt)
            self._update_hunter(dt, keys)
        self.hfield_t -= dt
        if self.hfield_t <= 0:
            self.hfield_t = 0.25
            self.hfield = self.w.bfs([self.w.nearest_free(self.w.cell_of(h.x, h.y))], HFIELD_DEPTH)
        if self.elapsed > ALARM_TIME and not self.alarm:
            self.alarm = True
            self.event("Fire alarm pulled - everyone is running!", (255, 120, 100))
            for a in self.agents:
                if a.state == "seated":
                    a.state, a.react_t = "alerted", random.uniform(0.2, 1.2)
        for a in self.agents:
            self._update_agent(a, dt)
        self._separate()
        self._check_contacts()
        self._update_world_objects(dt)
        if self.time_left <= 0 or not self.active_agents():
            self.over_t = 1.6
            self.event("TIME!" if self.time_left <= 0 else "Office cleared.", (255, 220, 120))

    def _update_hunter(self, dt, keys):
        h, w = self.h, self.w
        h.stun_t = max(0.0, h.stun_t - dt)
        h.blind_t = max(0.0, h.blind_t - dt)
        h.sprint_t = max(0.0, h.sprint_t - dt)
        h.sprint_cd = max(0.0, h.sprint_cd - dt)
        dx = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
        dy = (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP])
        if h.stun_t > 0:
            dx = dy = 0
        elif (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) and h.sprint_cd <= 0 and (dx or dy):
            h.sprint_t = SPRINT_TIME
            h.sprint_cd = SPRINT_TIME + SPRINT_COOLDOWN
        ln = math.hypot(dx, dy)
        if ln:
            dx, dy = dx / ln, dy / ln
            target = math.degrees(math.atan2(dy, dx))
            diff = (target - h.angle + 180) % 360 - 180
            h.angle += diff * min(1, dt * 14)
        sp = HUNTER_SPEED * (SPRINT_MULT if h.sprint_t > 0 else 1.0)
        h.vx = lerp(h.vx, dx * sp, min(1, dt * 12))
        h.vy = lerp(h.vy, dy * sp, min(1, dt * 12))
        mvx, mvy = h.vx + h.kx, h.vy + h.ky
        damp = math.exp(-6 * dt)
        h.kx *= damp
        h.ky *= damp
        nx = h.x + mvx * dt
        if w.is_free(nx, h.y):
            h.x = nx
        else:
            h.vx = h.kx = 0
        ny = h.y + mvy * dt
        if w.is_free(h.x, ny) and ny > 22:
            h.y = ny
        else:
            h.vy = h.ky = 0
        h.phase += math.hypot(h.vx, h.vy) * dt * 0.05

    def _alert(self, a, delay):
        if a.state == "seated":
            a.state = "alerted"
            a.react_t = delay

    def _stand_up(self, a):
        a.state = "flee"
        a.alert_mark = 0.8
        rad = math.radians(a.facing)
        a.chair.vx, a.chair.vy = -math.cos(rad) * 230, -math.sin(rad) * 230
        a.chair.spin = random.uniform(-260, 260)
        for _ in range(random.randint(1, 3)):
            self._spawn_paper(a.x + math.cos(rad) * 30, a.y + math.sin(rad) * 30,
                              random.uniform(-120, 120), random.uniform(-120, 120))
        a.target = self.w.nearest_free(self.w.cell_of(a.x, a.y))

    def _update_agent(self, a, dt):
        w, h = self.w, self.h
        a.invuln = max(0.0, a.invuln - dt)
        a.boost_t = max(0.0, a.boost_t - dt)
        a.dash_t = max(0.0, a.dash_t - dt)
        a.alert_mark = max(0.0, a.alert_mark - dt)
        a.punch_t = max(0.0, a.punch_t - dt)
        if a.state in ("caught", "escaped"):
            return
        ci = w.nearest_free(w.cell_of(a.x, a.y))
        hd = self.hfield[ci]
        if a.state == "seated":
            a.phase += dt * 4
            if self.intro_t <= 0 and hd <= ALERT_CELLS:
                self._alert(a, a.t["react"] * random.uniform(0.7, 1.3))
            else:
                for o in self.agents:
                    if o.state == "flee" and abs(o.x - a.x) < 110 and abs(o.y - a.y) < 110:
                        self._alert(a, a.t["react"] + random.uniform(0.5, 1.2))
                        break
            return
        if a.state == "alerted":
            a.react_t -= dt
            a.phase += dt * 4
            if a.react_t <= 0:
                self._stand_up(a)
            return
        # ---- flee ----
        if a.taunt_t > 0:              # Scott stands still for a moment after a punch
            a.taunt_t -= dt
            return
        if a.name == WEAPON_SEEKER and not self.weapon["taken"]:
            was = a.seek_weapon
            a.seek_weapon = hd <= KEN_TRIGGER
            if a.seek_weapon and not was:
                a.target = None
                if not a.announced:
                    a.announced = True
                    self.event(f"{a.name} is running for the weapon!", (230, 180, 120))
                    self.popup("WEAPON!", a.x, a.y - 36, (230, 180, 120), "small", 1.2)
        elif a.seek_weapon:
            a.seek_weapon = False
        if a.dept == "IT" and not a.dash_used and hd < 6:
            a.dash_used, a.dash_t = True, 1.1
            self.popup("DASH", a.x, a.y - 30, (255, 170, 90), "small", 0.8)
        a.replan_t -= dt
        if a.replan_t <= 0:
            a.replan_t = a.t["replan"]
            hc = w.nearest_free(w.cell_of(h.x, h.y))
            best, bc = 0, 10 ** 9
            for i in (0, 1):
                d = w.exit_field[i][ci]
                hdist = w.exit_field[i][hc]
                cost = d
                if hdist < d * 0.9 and hdist < 20:
                    cost += 60
                cost += random.uniform(0, 4) * a.t["noise"]
                if cost < bc:
                    best, bc = i, cost
            a.exit_choice = best
        speed = HUNTER_SPEED * a.t["speed"]
        if a.boost_t > 0:
            speed *= 1.3
        if a.dash_t > 0:
            speed *= 1.6
        if a.seek_weapon and not self.weapon["taken"]:
            speed *= KEN_BOOST
        if a.y < 80:
            speed *= 0.6
        # card tap at the exit door
        if a.y < 86 and not a.swiped:
            if a.swipe_t <= 0:
                main = MAIN_DOOR_X[0] <= a.x <= MAIN_DOOR_X[1]
                a.swipe_t = SWIPE_MAIN if main else SWIPE_SIDE
                if a.dept == "Logistics":
                    a.swipe_t *= 0.8
                a.swipe_total = a.swipe_t
            a.swipe_t -= dt
            a.vx = a.vy = 0.0
            if a.swipe_t <= 0:
                a.swiped = True
            return
        if a.target is None or math.hypot(w.center(a.target)[0] - a.x, w.center(a.target)[1] - a.y) < 3:
            seeking = a.seek_weapon and not self.weapon["taken"]
            field = w.weapon_field if seeking else w.exit_field[a.exit_choice]
            panic_r = PANIC_CELLS + (4 if a.name == ISO_NAME else 0)
            panic = clamp((panic_r - hd) / panic_r, 0, 1) * (0.35 if seeking else 1.0)
            best, bs = None, -1e9
            for n in w.nb8[ci]:
                fv = field[n]
                if fv >= 10 ** 6:
                    continue
                sc = -fv + panic * 2.1 * min(self.hfield[n], 30)
                sc += random.uniform(-1, 1) * a.t["noise"]
                if n == a.prev_cell:
                    sc -= 0.8
                if sc > bs:
                    best, bs = n, sc
            a.prev_cell = ci
            a.target = best if best is not None else ci
        tx, ty = w.center(a.target)
        dx, dy = tx - a.x, ty - a.y
        d = math.hypot(dx, dy)
        if d > 0.01:
            step = min(d, speed * dt)
            a.vx, a.vy = dx / d * speed, dy / d * speed
            a.x += dx / d * step
            a.y += dy / d * step
            target_ang = math.degrees(math.atan2(dy, dx))
            diff = (target_ang - a.angle + 180) % 360 - 180
            a.angle += diff * min(1, dt * 12)
        a.phase += speed * dt * 0.055
        if w.desk_adj[ci] and random.random() < dt * 0.9:
            self._spawn_paper(a.x, a.y, a.vx * 0.5 + random.uniform(-60, 60), a.vy * 0.5 + random.uniform(-60, 60))
        if a.seek_weapon and not self.weapon["taken"]:
            if math.hypot(a.x - self.weapon["x"], a.y - self.weapon["y"]) < 22:
                self.weapon["taken"] = True
                a.has_poop = True
                a.seek_weapon = False
                a.target = None
                self.event(f"{a.name} grabbed the weapon!", (230, 170, 110))
                self.popup("ARMED!", a.x, a.y - 36, (230, 170, 110), "pop", 1.3)
        if a.y < EXIT_Y:
            a.state = "escaped"
            self.escaped.append(a)
            self.flashes.append([a.x, a.y, (90, 255, 160), 0.5, 0.5])
            self.popup("ESCAPED", a.x, a.y + 30, (255, 110, 100), "small", 1.2)
            self.event(f"{a.name} escaped", (255, 130, 120))

    def _separate(self):
        movers = [a for a in self.agents if a.state == "flee"]
        for i, a in enumerate(movers):
            for b in movers[i + 1:]:
                dx, dy = b.x - a.x, b.y - a.y
                if abs(dx) > 16 or abs(dy) > 16:
                    continue
                d = math.hypot(dx, dy)
                if 0.01 < d < 16:
                    push = (16 - d) / 2
                    ux, uy = dx / d * push, dy / d * push
                    if self.w.is_free(a.x - ux, a.y - uy):
                        a.x -= ux
                        a.y -= uy
                    if self.w.is_free(b.x + ux, b.y + uy):
                        b.x += ux
                        b.y += uy

    def _check_contacts(self):
        h = self.h
        if self.intro_t > 0:
            return
        if not self.weapon["taken"] and math.hypot(h.x - self.weapon["x"], h.y - self.weapon["y"]) < 24:
            self.weapon["taken"] = True
            self.score += 50
            self.popup("CONFISCATED +50", h.x, h.y - 40, (220, 200, 160), "small", 1.4)
            self.event("You confiscated the weapon", (220, 200, 160))
        if h.stun_t > 0:
            return
        for a in self.agents:
            if a.state not in ("seated", "alerted", "flee") or a.invuln > 0:
                continue
            if abs(a.x - h.x) > CATCH_DIST or abs(a.y - h.y) > CATCH_DIST:
                continue
            if math.hypot(a.x - h.x, a.y - h.y) > CATCH_DIST:
                continue
            if a.shields > 0:
                self._iso_punch(a)
            elif a.has_poop:
                self._poop_counter(a)
            else:
                self._catch(a)
            break

    def _iso_punch(self, a):
        h = self.h
        a.shields -= 1
        a.invuln = 2.8
        a.punch_t = 0.35
        if a.state != "flee":
            self._stand_up(a)
        a.taunt_t = 0.5
        a.target = None
        h.stun_t = ISO_STUN
        h.sprint_t = 0
        dx, dy = h.x - a.x, h.y - a.y
        d = math.hypot(dx, dy) or 1
        h.kx, h.ky = dx / d * 520, dy / d * 520          # visible knock-back slide
        h.vx = h.vy = 0
        self.shake, self.shake_amp = 0.6, 22
        self.weak_t = ISO_STUN
        mx, my = (a.x + h.x) / 2, (a.y + h.y) / 2
        self.flashes.append([mx, my, (255, 255, 255), 0.4, 0.4])
        self.popup("", mx, my - 10, (0, 0, 0), dur=0.7, surf=self.a.pow_)
        self.event(f"{a.name} punched you!  Shields left: {a.shields}", (210, 170, 255))

    def _poop_counter(self, a):
        a.has_poop = False
        a.invuln = 2.2
        a.boost_t = 1.6
        if a.state != "flee":
            self._stand_up(a)
        self.projectiles.append(dict(x0=a.x, y0=a.y, t=0.0, dur=0.35))
        self.event(f"{a.name} broke free and threw it at you!", (230, 170, 110))

    def _catch(self, a):
        a.state = "caught"
        a.caught_angle = a.angle
        if self.elapsed - self.last_catch <= COMBO_WINDOW:
            self.combo += 1
        else:
            self.combo = 1
        self.last_catch = self.elapsed
        mult = min(self.combo, 5)
        pts = a.points * mult
        self.score += pts
        self.caught.append(a)
        txt = f"+{pts}" + (f"  x{mult}" if mult > 1 else "")
        self.popup(txt, a.x, a.y - 34, (255, 214, 110), "pop", 1.2)
        self.event(f"Caught {a.name}  +{pts}", (150, 230, 160))
        self.flashes.append([a.x, a.y, (255, 220, 140), 0.3, 0.3])
        self.shake, self.shake_amp = max(self.shake, 0.12), 8
        if a.name == LOVE_TARGET:
            self.love_t = 1.6
            self.love_agent = a
            self.love_dark = None

    def _spawn_paper(self, x, y, vx, vy):
        if len(self.papers) < 40:
            self.papers.append([x, y, vx, vy, random.uniform(0, 360), random.uniform(-400, 400)])

    def _update_world_objects(self, dt):
        h = self.h
        movers = [(h.x, h.y, h.vx, h.vy)] + [(a.x, a.y, a.vx, a.vy) for a in self.agents if a.state == "flee"]
        for c in self.chairs:
            for (mx, my, mvx, mvy) in movers:
                dx, dy = c.x - mx, c.y - my
                if abs(dx) > 20 or abs(dy) > 20:
                    continue
                d = math.hypot(dx, dy)
                if 0.01 < d < 20:
                    c.vx += dx / d * 140 + mvx * 0.25
                    c.vy += dy / d * 140 + mvy * 0.25
                    c.spin += random.uniform(-200, 200)
            c.update(dt, self.w)
        keep = []
        for p in self.papers:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] += p[5] * dt
            damp = math.exp(-3.5 * dt)
            p[2] *= damp
            p[3] *= damp
            p[5] *= damp
            if abs(p[2]) + abs(p[3]) < 8:
                self._draw_paper(self.bg, p[0], p[1], p[4])
            else:
                keep.append(p)
        self.papers = keep
        for pr in self.projectiles:
            pr["t"] += dt
            if pr["t"] >= pr["dur"]:
                h.blind_t = POOP_BLIND
                self.splat = self._make_splat()
                self.shake, self.shake_amp = max(self.shake, 0.25), 12
        self.projectiles = [p for p in self.projectiles if p["t"] < p["dur"]]

    def _draw_paper(self, surf, x, y, ang, ox=0, oy=0):
        a = math.radians(ang)
        f = (math.cos(a), math.sin(a))
        r = (-f[1], f[0])
        pygame.draw.polygon(surf, (150, 150, 150), quad((x - ox + 1, y - oy + 2), f, r, 6, 8))
        pygame.draw.polygon(surf, (244, 244, 240), quad((x - ox, y - oy), f, r, 6, 8))

    def _make_splat(self):
        s = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        rng = random.Random()
        cx, cy = SCREEN_W / 2 + rng.uniform(-80, 80), SCREEN_H / 2 + rng.uniform(-60, 40)
        cols = [(70, 44, 20), (92, 58, 26), (110, 72, 34), (60, 38, 18)]
        for i in range(70):
            ang = rng.uniform(0, math.tau)
            dist = abs(rng.gauss(0, 170))
            r = rng.uniform(30, 110) * (1 - min(dist, 400) / 520)
            x, y = cx + math.cos(ang) * dist, cy + math.sin(ang) * dist * 0.75
            pygame.draw.circle(s, rng.choice(cols) + (245,), (x, y), max(6, r))
        for i in range(40):
            ang = rng.uniform(0, math.tau)
            d = rng.uniform(260, 520)
            pygame.draw.circle(s, rng.choice(cols) + (235,), (cx + math.cos(ang) * d, cy + math.sin(ang) * d * 0.7),
                               rng.uniform(4, 16))
        for i in range(25):
            x, y = cx + rng.uniform(-200, 200), cy + rng.uniform(-150, 150)
            pygame.draw.ellipse(s, (150, 106, 62, 160), (x, y, rng.uniform(8, 30), rng.uniform(4, 12)))
        drips = [(cx + rng.uniform(-300, 300), cy + rng.uniform(-40, 140), rng.uniform(8, 22), rng.uniform(80, 260))
                 for _ in range(14)]
        return dict(s=s, drips=drips)

    # ---------- draw ----------
    def camera(self):
        cx = clamp(self.h.x - SCREEN_W / 2, -40, WORLD_W - SCREEN_W + 40)
        cy = clamp(self.h.y - SCREEN_H / 2, -70, WORLD_H - SCREEN_H + 20)
        if self.shake > 0:
            k = self.shake_amp * min(1, self.shake * 2)
            cx += random.uniform(-k, k)
            cy += random.uniform(-k, k)
        return int(cx), int(cy)

    def draw_lighting(self, screen, cx, cy, cone=True):
        A = self.a
        lv = A.lv
        lv.fill((120, 122, 132))
        ox, oy = cx // LS, cy // LS
        lsrc = pygame.Rect(ox, oy, lv.get_width(), lv.get_height()).clip(self.w.light.get_rect())
        lv.blit(self.w.light, (lsrc.x - ox, lsrc.y - oy), lsrc)
        if cone:
            h = self.h
            c = A.cone_at(h.angle)
            lv.blit(c, ((h.x - cx) / LS - c.get_width() / 2, (h.y - cy) / LS - c.get_height() / 2),
                    special_flags=pygame.BLEND_RGB_ADD)
        pygame.transform.scale(lv, A.lv_big.get_size(), A.lv_big)
        screen.blit(A.lv_big, (-(cx % LS), -(cy % LS)), special_flags=pygame.BLEND_RGB_MULT)

    def draw(self, screen, cam=None, hud=True):
        A = self.a
        cx, cy = cam if cam else self.camera()
        screen.fill((10, 12, 16))
        src = pygame.Rect(cx, cy, SCREEN_W, SCREEN_H).clip(self.bg.get_rect())
        screen.blit(self.bg, (src.x - cx, src.y - cy), src)
        for p in self.papers:
            self._draw_paper(screen, p[0], p[1], p[4], cx, cy)
        self._draw_weapon(screen, cx, cy)
        for c in self.chairs:
            if -40 < c.x - cx < SCREEN_W + 40 and -40 < c.y - cy < SCREEN_H + 40:
                spr = c.cache.get(c.facing)
                screen.blit(spr, (c.x - cx - spr.get_width() / 2, c.y - cy - spr.get_height() / 2))
        order = sorted(self.agents, key=lambda a: (a.state != "caught", a.y))
        blink = int(pygame.time.get_ticks() / 80) % 2 == 0
        for a in order:
            if a.state == "escaped":
                continue
            ox = oy = 0
            if a.punch_t > 0:
                k = math.sin(a.punch_t / 0.35 * math.pi) * 16
                ang = math.atan2(self.h.y - a.y, self.h.x - a.x)
                ox, oy = math.cos(ang) * k, math.sin(ang) * k
            x, y = a.x - cx + ox, a.y - cy + oy
            if x < -60 or y < -60 or x > SCREEN_W + 60 or y > SCREEN_H + 60:
                continue
            if a.state != "caught":
                ring = A.rings[a.dept]
                screen.blit(ring, (x - 20, y - 12 + 4))
            else:
                screen.blit(A.shadow, (x - 13, y - 5))
            if a.state == "caught":
                spr = a.sprites.get("caught", 0, a.caught_angle)
            elif a.state == "flee":
                spr = a.sprites.get("run", a.phase, a.angle)
                if a.dash_t > 0:
                    for k in (1, 2):
                        screen.blit(spr, (x - a.vx * 0.02 * k - spr.get_width() / 2,
                                          y - a.vy * 0.02 * k - spr.get_height() / 2),
                                    special_flags=pygame.BLEND_RGBA_ADD)
            else:
                spr = a.sprites.get("type", a.phase, a.facing)
            if a.invuln > 0 and blink and a.state != "caught":
                continue
            screen.blit(spr, (x - spr.get_width() / 2, y - spr.get_height() / 2))
        h = self.h
        hx, hy = h.x - cx, h.y - cy
        screen.blit(A.hshadow, (hx - 20, hy - 6))
        hs = A.hunter.get(h.phase, math.hypot(h.vx, h.vy) > 20, h.angle)
        screen.blit(hs, (hx - hs.get_width() / 2, hy - hs.get_height() / 2))
        # ---- lighting ----
        self.draw_lighting(screen, cx, cy)
        if self.intro_t > 0.4 and random.random() < 0.5:
            screen.fill((150, 150, 150), special_flags=pygame.BLEND_RGB_MULT)
        # ---- additive glows (all pre-built) ----
        t = pygame.time.get_ticks() / 1000
        for i, p in enumerate(self.w.exit_sign_pos):
            g = self.w.exit_glows[int((math.sin(t * 3 + i) + 1) * 2.5)]
            screen.blit(g, (p[0] - cx - 35, p[1] - cy - 20), special_flags=pygame.BLEND_RGB_ADD)
        for x, y, col, tl, dur in self.flashes:
            k = tl / dur
            rr = int(50 + 100 * (1 - k))
            g = pygame.transform.scale(self.w.flash_glow, (rr * 2, rr * 2))
            g.fill(tuple(int(c * k) for c in col), special_flags=pygame.BLEND_RGB_MULT)
            screen.blit(g, (x - cx - rr, y - cy - rr), special_flags=pygame.BLEND_RGB_ADD)
        if not self.weapon["taken"]:
            g = self.w.weapon_glows[int((math.sin(t * 4) + 1) * 2.5)]
            screen.blit(g, (self.weapon["x"] - cx - 45, self.weapon["y"] - cy - 45), special_flags=pygame.BLEND_RGB_ADD)
        # ---- overlays in world space ----
        for a in self.agents:
            if a.state == "escaped":
                continue
            x, y = a.x - cx, a.y - cy
            if x < -80 or y < -80 or x > SCREEN_W + 80 or y > SCREEN_H + 80:
                continue
            if self.show_names and a.state != "caught":
                screen.blit(a.label, (x - a.label.get_width() / 2, y + 22))
            if a.alert_mark > 0:
                bounce = math.sin((0.8 - a.alert_mark) * 14) * 3
                screen.blit(A.alert, (x - A.alert.get_width() / 2, y - 48 + bounce))
            if a.shields > 0 and a.state != "caught":
                for k in range(a.shields):
                    sx = x - 9 + k * 16
                    pts = [(sx - 6, y - 36), (sx + 6, y - 36), (sx + 6, y - 29), (sx, y - 23), (sx - 6, y - 29)]
                    pygame.draw.polygon(screen, (170, 130, 240), pts)
                    pygame.draw.polygon(screen, (240, 230, 255), pts, 1)
            if a.has_poop:
                screen.blit(A.poop16, (x - 8, y - 40))
            if a.swipe_t > 0 and not a.swiped and a.state == "flee":
                k = 1 - a.swipe_t / a.swipe_total
                pygame.draw.circle(screen, (30, 34, 40), (x, y - 36), 10)
                pygame.draw.arc(screen, (90, 230, 150), (x - 10, y - 46, 20, 20), math.pi / 2,
                                math.pi / 2 + k * math.tau, 3)
        for pr in self.projectiles:
            k = pr["t"] / pr["dur"]
            x = lerp(pr["x0"], h.x, k) - cx
            y = lerp(pr["y0"], h.y, k) - cy - math.sin(k * math.pi) * 60
            ps = A.poop22.get(k * 720)
            screen.blit(ps, (x - ps.get_width() / 2, y - ps.get_height() / 2))
        # stun stars orbiting the hunter's head
        if h.stun_t > 0:
            for i in range(3):
                ang = t * 6 + i * math.tau / 3
                sx, sy = hx + math.cos(ang) * 26, hy - 30 + math.sin(ang) * 9
                pygame.draw.polygon(screen, (255, 230, 70), star_points(sx, sy, 8, 3.5, 5, t * 4))
                pygame.draw.polygon(screen, (120, 80, 0), star_points(sx, sy, 8, 3.5, 5, t * 4), 1)
        for p in self.popups:
            k = p["t"] / p["dur"]
            s = p["s"]
            s.set_alpha(int(255 * (1 - k ** 2)))
            screen.blit(s, (p["x"] - cx - s.get_width() / 2, p["y"] - cy - 30 * k - s.get_height() / 2))
        # ---- screen effects ----
        if h.stun_t > 0:
            A.red_vig.set_alpha(int(255 * min(1, h.stun_t / 0.6)))
            screen.blit(A.red_vig, (0, 0))
        if self.weak_t > 0:
            k = ISO_STUN - self.weak_t
            sc = 1.0 + max(0.0, 0.7 - k * 3.5)
            s = A.weak if sc <= 1.0 else pygame.transform.scale(
                A.weak, (int(A.weak.get_width() * sc), int(A.weak.get_height() * sc)))
            jx = random.uniform(-4, 4) if k < 0.4 else 0
            screen.blit(s, (SCREEN_W / 2 - s.get_width() / 2 + jx, 200 - s.get_height() / 2))
            # stun countdown bar
            bw = 320
            bx, by = SCREEN_W / 2 - bw / 2, 270
            screen.blit(A.stunned, (SCREEN_W / 2 - A.stunned.get_width() / 2, by - 4))
            pygame.draw.rect(screen, (40, 10, 10), (bx, by + 36, bw, 12), border_radius=6)
            pygame.draw.rect(screen, (255, 70, 60), (bx, by + 36, bw * h.stun_t / ISO_STUN, 12), border_radius=6)
            pygame.draw.rect(screen, (255, 200, 200), (bx, by + 36, bw, 12), 1, border_radius=6)
        if h.blind_t > 0 and self.splat:
            self._draw_splat(screen)
        if self.love_t > 0 and self.love_agent:
            self._draw_love(screen, cx, cy)
        if hud:
            self._draw_hud(screen, cx, cy)
        if self.intro_t > 0:
            k = clamp(self.intro_t / 1.3, 0, 1)
            s = outlined(self.f["big"], "5:59 PM", (255, 255, 255), (0, 0, 0), 3)
            s.set_alpha(int(255 * k))
            screen.blit(s, (SCREEN_W / 2 - s.get_width() / 2, SCREEN_H / 2 - 120))
            s2 = outlined(self.f["mid"], "Nobody leaves early.", (220, 220, 225))
            s2.set_alpha(int(255 * k))
            screen.blit(s2, (SCREEN_W / 2 - s2.get_width() / 2, SCREEN_H / 2 - 60))

    def _draw_weapon(self, screen, cx, cy):
        if self.weapon["taken"]:
            return
        x, y = self.weapon["x"] - cx, self.weapon["y"] - cy
        t = pygame.time.get_ticks() / 1000
        pygame.draw.circle(screen, (60, 62, 68), (x, y + 4), 16)
        pygame.draw.circle(screen, (140, 142, 150), (x, y + 2), 15)
        pygame.draw.circle(screen, (100, 102, 110), (x, y + 2), 15, 2)
        screen.blit(self.a.poop26, (x - 13, y - 16 + math.sin(t * 3) * 2))

    def _draw_splat(self, screen):
        h = self.h
        elapsed = POOP_BLIND - h.blind_t
        sp = self.splat
        layer = sp["s"]
        for x, y, wdt, ln in sp["drips"]:       # drips grow on the same surface (no copy)
            l = ln * min(1, elapsed / 2.2)
            pygame.draw.rect(layer, (78, 50, 22, 235), (x - wdt / 2, y, wdt, l), border_radius=int(wdt / 2))
            pygame.draw.circle(layer, (78, 50, 22, 235), (x, y + l), wdt * 0.62)
        layer.set_alpha(255 if h.blind_t > 1.0 else int(255 * h.blind_t))
        screen.blit(layer, (0, 0))

    def _draw_love(self, screen, cx, cy):
        A = self.a
        a = self.love_agent
        x, y = a.x - cx, a.y - cy
        if self.love_dark is None:          # build once per trigger
            dark = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            dark.fill((0, 0, 0, 190))
            pygame.draw.circle(dark, (0, 0, 0, 60), (x, y), 110)
            pygame.draw.circle(dark, (0, 0, 0, 0), (x, y), 70)
            self.love_dark = soften(dark, 6)
        k = clamp((1.6 - self.love_t) / 0.5, 0, 1)
        self.love_dark.set_alpha(int(255 * k))
        screen.blit(self.love_dark, (0, 0))
        ty = y - 140 if y > 260 else y + 90
        for s in (A.love_glow, A.love):
            s.set_alpha(int(255 * k))
            screen.blit(s, (SCREEN_W / 2 - s.get_width() / 2, ty))

    def _draw_hud(self, screen, cx, cy):
        if not hasattr(self, "_bar"):
            self._bar = pygame.Surface((SCREEN_W, 52), pygame.SRCALPHA)
            self._bar.fill((8, 10, 14, 200))
        screen.blit(self._bar, (0, 0))
        pygame.draw.line(screen, (60, 66, 80), (0, 52), (SCREEN_W, 52))
        m, s = divmod(int(math.ceil(self.time_left)), 60)
        col = (255, 90, 80) if self.time_left < 15 else (240, 242, 246)
        screen.blit(self.f["hud"].render(f"{m:01d}:{s:02d}", True, col), (24, 10))
        pygame.draw.rect(screen, (50, 54, 64), (24, 42, 140, 4))
        pygame.draw.rect(screen, col, (24, 42, 140 * self.time_left / GAME_TIME, 4))
        # sprint meter
        h = self.h
        sx = 190
        lab = self.f["small"].render("SPRINT", True, (150, 156, 170))
        screen.blit(lab, (sx, 18))
        bx = sx + lab.get_width() + 8
        pygame.draw.rect(screen, (50, 54, 64), (bx, 22, 90, 10), border_radius=5)
        if h.sprint_t > 0:
            pygame.draw.rect(screen, (120, 200, 255), (bx, 22, 90 * h.sprint_t / SPRINT_TIME, 10), border_radius=5)
        elif h.sprint_cd > 0:
            k = 1 - h.sprint_cd / (SPRINT_TIME + SPRINT_COOLDOWN)
            pygame.draw.rect(screen, (90, 96, 110), (bx, 22, 90 * k, 10), border_radius=5)
        else:
            pygame.draw.rect(screen, (120, 230, 160), (bx, 22, 90, 10), border_radius=5)
        sc = self.f["hud"].render(f"{self.score:,}", True, (255, 208, 100))
        lab = self.f["small"].render("SCORE", True, (150, 156, 170))
        screen.blit(lab, (SCREEN_W / 2 - sc.get_width() / 2 - lab.get_width() - 12 + 40, 18))
        screen.blit(sc, (SCREEN_W / 2 - sc.get_width() / 2 + 40, 10))
        x = SCREEN_W - 470
        for name, val, c in (("CAUGHT", len(self.caught), (150, 230, 160)),
                             ("ESCAPED", len(self.escaped), (255, 130, 120)),
                             ("REMAINING", len(self.active_agents()), (230, 232, 236))):
            l = self.f["small"].render(name, True, (150, 156, 170))
            v = self.f["hud"].render(str(val), True, c)
            screen.blit(l, (x, 18))
            screen.blit(v, (x + l.get_width() + 8, 10))
            x += l.get_width() + v.get_width() + 30
        if self.combo > 1 and self.elapsed - self.last_catch < COMBO_WINDOW:
            k = 1 - (self.elapsed - self.last_catch) / COMBO_WINDOW
            c = (255, int(200 - 30 * min(self.combo, 5)), 80)
            s = outlined(self.f["mid"], f"x{min(self.combo, 5)} COMBO", c)
            s.set_alpha(int(255 * min(1, k * 2)))
            screen.blit(s, (SCREEN_W / 2 - s.get_width() / 2, 60))
        y = SCREEN_H - 30
        for s, tl in reversed(self.events):
            s.set_alpha(int(255 * min(1, tl)))
            pygame.draw.rect(screen, (0, 0, 0), (16, y - 3, s.get_width() + 16, s.get_height() + 6))
            screen.blit(s, (24, y))
            y -= s.get_height() + 10
        mm, scl = self.w.minimap, self.w.mm_scale
        mx, my = SCREEN_W - mm.get_width() - 16, SCREEN_H - mm.get_height() - 16
        screen.blit(mm, (mx, my))
        pygame.draw.rect(screen, (200, 206, 220), (mx + cx * scl, my + cy * scl, SCREEN_W * scl, SCREEN_H * scl), 1)
        for a in self.agents:
            if a.state == "escaped":
                continue
            col = (90, 90, 96) if a.state == "caught" else a.t["color"]
            r = 4 if a.name == ISO_NAME else 2.5
            pygame.draw.circle(screen, col, (mx + a.x * scl, my + a.y * scl), r)
            if a.has_poop:
                pygame.draw.circle(screen, (150, 100, 50), (mx + a.x * scl, my + a.y * scl), 5, 1)
        if not self.weapon["taken"]:
            pygame.draw.circle(screen, (150, 100, 50), (mx + self.weapon["x"] * scl, my + self.weapon["y"] * scl), 3)
        pygame.draw.circle(screen, (255, 255, 255), (mx + self.h.x * scl, my + self.h.y * scl), 4)

    def grade(self):
        n = len(self.caught) / len(self.agents)
        return "S" if n >= 0.8 else "A" if n >= 0.6 else "B" if n >= 0.4 else "C"


# =====================================================================
# SCREENS
# =====================================================================
def load_best():
    try:
        with open(HIGHSCORE_FILE) as fh:
            return int(json.load(fh).get("best", 0))
    except Exception:
        return 0


def save_best(v):
    try:
        with open(HIGHSCORE_FILE, "w") as fh:
            json.dump({"best": v}, fh)
    except Exception:
        pass


def _title_world(screen, game, cam):
    cx, cy = cam
    screen.fill((10, 12, 16))
    src = pygame.Rect(cx, cy, SCREEN_W, SCREEN_H).clip(game.bg.get_rect())
    screen.blit(game.bg, (src.x - cx, src.y - cy), src)
    for c in game.chairs:
        spr = c.cache.get(c.facing)
        screen.blit(spr, (c.x - cx - spr.get_width() / 2, c.y - cy - spr.get_height() / 2))
    ph = pygame.time.get_ticks() / 250
    for a in game.agents:
        spr = a.sprites.get("type", ph + a.phase, a.facing)
        screen.blit(spr, (a.x - cx - spr.get_width() / 2, a.y - cy - spr.get_height() / 2))
    game.draw_lighting(screen, cx, cy, cone=False)


def draw_title(screen, game, fonts, t, best):
    cam = (int(WORLD_W / 2 - SCREEN_W / 2 + math.sin(t * 0.15) * 450), int(120 + math.sin(t * 0.1) * 60))
    _title_world(screen, game, cam)
    if not hasattr(draw_title, "dark"):
        draw_title.dark = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        draw_title.dark.fill((4, 6, 10, 150))
        draw_title.title = outlined(fonts["title"], "GAC OFFICE HUNT", (244, 244, 248), (0, 0, 0), 3)
    screen.blit(draw_title.dark, (0, 0))
    screen.blit(draw_title.title, (80, 100))
    screen.blit(fonts["mid"].render("Catch them before they clock out.", True, (210, 214, 224)), (84, 186))
    pygame.draw.line(screen, (230, 70, 60), (84, 228), (380, 228), 3)
    rules = [
        ("MOVE", "WASD / Arrow keys"),
        ("SPRINT", "Shift - x1.5 speed for 1.5 s, 4 s cooldown"),
        ("CATCH", "Touch a colleague. Catch fast for a combo (up to x5)."),
        ("EXITS", "Main door (2.5 s card tap) and Printer 4525 door (1.3 s)."),
        ("ISO", "Scott Cheong has 2 shields. Each hit stuns you for 2 s."),
        ("WEAPON", "Chase Ken and he runs for the vacant room. Get there first."),
        ("BONUS", "Private offices 200 · Maria Lam 300 · Scott Cheong 500"),
    ]
    y = 252
    for k, v in rules:
        screen.blit(fonts["smallb"].render(k, True, (240, 90, 80)), (84, y))
        screen.blit(fonts["small"].render(v, True, (226, 228, 236)), (190, y))
        y += 34
    if best:
        screen.blit(fonts["small"].render(f"BEST  {best:,}", True, (255, 208, 100)), (84, y + 12))
    if int(t * 2) % 2 == 0:
        p = fonts["mid"].render("Press ENTER to start", True, (255, 255, 255))
        screen.blit(p, (84, SCREEN_H - 80))


def draw_result(screen, game, fonts, best, new_best):
    game.draw(screen, hud=False)
    dark = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    dark.fill((4, 6, 10, 200))
    screen.blit(dark, (0, 0))
    g = game.grade()
    gc = {"S": (255, 208, 90), "A": (150, 230, 160), "B": (140, 190, 255), "C": (220, 220, 220)}[g]
    screen.blit(outlined(fonts["title"], g, gc, (0, 0, 0), 4), (90, 90))
    screen.blit(fonts["big"].render(f"{game.score:,}", True, (255, 255, 255)), (200, 104))
    screen.blit(fonts["small"].render("NEW BEST!" if new_best else f"BEST  {best:,}", True, (255, 208, 100)),
                (204, 170))
    screen.blit(fonts["smallb"].render(f"CAUGHT  {len(game.caught)}", True, (150, 230, 160)), (90, 230))
    y = 262
    for i, a in enumerate(game.caught):
        screen.blit(fonts["small"].render(a.name, True, (210, 230, 214)), (90 + (i // 13) * 200, y + (i % 13) * 26))
    screen.blit(fonts["smallb"].render(f"ESCAPED  {len(game.escaped)}", True, (255, 130, 120)), (560, 230))
    for i, a in enumerate(game.escaped):
        screen.blit(fonts["small"].render(a.name, True, (236, 200, 196)), (560 + (i // 13) * 200, y + (i % 13) * 26))
    p = fonts["mid"].render("ENTER  play again      ESC  quit", True, (220, 222, 230))
    screen.blit(p, (90, SCREEN_H - 80))


def make_fonts():
    F = pygame.font.Font
    return dict(tag=F(None, 17), small=F(None, 24), smallb=F(None, 26), hud=F(None, 40), pop=F(None, 34),
                mid=F(None, 36), big=F(None, 72), huge=F(None, 110), title=F(None, 110), alert=F(None, 44))


# =====================================================================
# MAIN LOOP (async = pygbag ready)
# =====================================================================
async def main():
    pygame.init()
    try:
        screen = pygame.display.set_mode((SCREEN_W, SCREEN_H), pygame.SCALED)
    except Exception:
        screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    pygame.display.set_caption("GAC Office Hunt")
    clock = pygame.time.Clock()
    fonts = make_fonts()
    screen.fill((0, 0, 0))
    screen.blit(fonts["mid"].render("Building the office...", True, (220, 220, 220)), (40, SCREEN_H - 70))
    pygame.display.flip()
    await asyncio.sleep(0)
    world = World()
    assets = Assets(fonts)
    best = load_best()
    game = Game(world, assets, best)
    state, t, new_best, paused = "title", 0.0, False, False
    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000, 1 / 20)
        t += dt
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif state in ("title", "result") and e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                    game = Game(world, assets, best)
                    state, paused = "play", False
                elif state == "play" and e.key == pygame.K_p:
                    paused = not paused
                elif state == "play" and e.key == pygame.K_r:
                    game = Game(world, assets, best)
                elif state == "play" and e.key == pygame.K_TAB:
                    game.show_names = not game.show_names
        if state == "title":
            draw_title(screen, game, fonts, t, best)
        elif state == "play":
            if not paused:
                game.update(dt, pygame.key.get_pressed())
            game.draw(screen)
            if paused:
                s = outlined(fonts["big"], "PAUSED", (255, 255, 255))
                screen.blit(s, (SCREEN_W / 2 - s.get_width() / 2, SCREEN_H / 2 - 40))
            if game.finished:
                new_best = game.score > best
                if new_best:
                    best = game.score
                    save_best(best)
                state = "result"
        elif state == "result":
            draw_result(screen, game, fonts, best, new_best)
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
